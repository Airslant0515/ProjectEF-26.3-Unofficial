package moze_intel.projecte.rendering;

import com.mojang.blaze3d.vertex.PoseStack;
import com.mojang.blaze3d.vertex.PoseStack.Pose;
import com.mojang.blaze3d.vertex.VertexConsumer;
import net.minecraft.client.renderer.SubmitNodeCollector;
import net.minecraft.client.renderer.entity.EntityRenderer;
import net.minecraft.client.renderer.entity.EntityRendererProvider;
import net.minecraft.client.renderer.entity.state.EntityRenderState;
import net.minecraft.client.renderer.rendertype.RenderType;
import net.minecraft.client.renderer.state.level.CameraRenderState;
import net.minecraft.core.BlockPos;
import net.minecraft.resources.Identifier;
import net.minecraft.world.entity.Entity;
import org.jetbrains.annotations.NotNull;

/**
 * Based on {@link net.minecraft.client.renderer.entity.DragonFireballRenderer}
 */
public class EntitySpriteRenderer<ENTITY extends Entity> extends EntityRenderer<ENTITY, EntityRenderState> {

	private final RenderType renderType;

	public EntitySpriteRenderer(EntityRendererProvider.Context context, Identifier texture) {
		super(context);
		this.renderType = PERenderType.SPRITE_RENDERER.apply(texture);
	}

	@Override
	protected int getBlockLightLevel(@NotNull ENTITY entity, @NotNull BlockPos pos) {
		return 15;
	}

	@NotNull
	@Override
	public EntityRenderState createRenderState() {
		return new EntityRenderState();
	}

	@Override
	public void submit(@NotNull EntityRenderState state, @NotNull PoseStack matrix, @NotNull SubmitNodeCollector collector, @NotNull CameraRenderState camera) {
		matrix.pushPose();
		matrix.scale(0.5F, 0.5F, 0.5F);
		matrix.rotate(camera.orientation);
		collector.submitCustomGeometry(matrix, this.renderType, (pose, builder) -> buildQuad(pose, builder, -1));
		if (state.outlineColor != 0 && this.renderType.outline().isPresent()) {
			collector.submitCustomGeometry(matrix, this.renderType.outline().get(), (pose, builder) -> buildQuad(pose, builder, state.outlineColor));
		}
		matrix.popPose();
	}

	private static void buildQuad(Pose pose, VertexConsumer builder, int color) {
		vertex(builder, pose, 0, 0, 0, 1, color);
		vertex(builder, pose, 1, 0, 1, 1, color);
		vertex(builder, pose, 1, 1, 1, 0, color);
		vertex(builder, pose, 0, 1, 0, 0, color);
	}

	private static void vertex(VertexConsumer consumer, Pose pose, float x, int y, int u, int v, int color) {
		consumer.addVertex(pose, x - 0.5F, y, 0)
				.setUv(u, v)
				.setColor(color);
	}
}