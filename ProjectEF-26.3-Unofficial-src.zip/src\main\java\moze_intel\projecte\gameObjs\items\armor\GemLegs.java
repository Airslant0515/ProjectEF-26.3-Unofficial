package moze_intel.projecte.gameObjs.items.armor;

import it.unimi.dsi.fastutil.ints.Int2LongMap;
import it.unimi.dsi.fastutil.ints.Int2LongOpenHashMap;
import java.util.function.Consumer;
import moze_intel.projecte.utils.WorldHelper;
import moze_intel.projecte.utils.text.PELang;
import net.fabricmc.api.EnvType;
import net.fabricmc.loader.api.FabricLoader;
import net.minecraft.client.Minecraft;
import net.minecraft.client.player.LocalPlayer;
import net.minecraft.network.chat.Component;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.EquipmentSlot;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.TooltipFlag;
import net.minecraft.world.item.component.TooltipDisplay;
import net.minecraft.world.item.equipment.ArmorType;
import net.minecraft.world.phys.Vec3;
import org.jetbrains.annotations.NotNull;
import org.jetbrains.annotations.Nullable;

public class GemLegs extends GemArmorBase {

	private static final Vec3 DOWNWARD_MOVEMENT = new Vec3(0, -0.32F, 0);
	/**
	 * Tracks the last game time a player jumped, so that we can tell the difference between a jump and the fast downward movement our own physics applies.
	 */
	private final Int2LongMap lastJumpTracker = new Int2LongOpenHashMap();

	public GemLegs(Properties props) {
		super(ArmorType.LEGGINGS, props);
		if (FabricLoader.getInstance().getEnvironmentType() == EnvType.CLIENT) {
			ClientHelper.register();
		}
	}

	@Override
	public void appendHoverText(@NotNull ItemStack stack, @NotNull Item.TooltipContext context, @NotNull TooltipDisplay display, @NotNull Consumer<Component> tooltip, @NotNull TooltipFlag flags) {
		super.appendHoverText(stack, context, display, tooltip, flags);
		tooltip.accept(PELang.GEM_LORE_LEGS.translate());
	}

	@Override
	public void inventoryTick(@NotNull ItemStack stack, @NotNull ServerLevel level, @NotNull Entity entity, @Nullable EquipmentSlot slot) {
		super.inventoryTick(stack, level, entity, slot);
		if (isArmorSlot(slot) && entity instanceof Player player && player.isSecondaryUseActive()) {
			WorldHelper.repelEntitiesSWRG(level, player.getBoundingBox().inflate(3.5), player);
			if (player.getDeltaMovement().y() < -0.08) {
				for (Entity e : player.level().getEntities(player, player.getBoundingBox().move(player.getDeltaMovement()).inflate(2.0D),
						ent -> ent.isAlive() && ent.isPickable() && ent instanceof LivingEntity)) {
					e.hurtServer(level, level.damageSources().playerAttack(player), (float) -player.getDeltaMovement().y() * 6.0F);
				}
			}
		}
	}

	private boolean jumpedRecently(Player player) {
		return lastJumpTracker.containsKey(player.getId()) && player.level().getGameTime() - lastJumpTracker.get(player.getId()) < 5;
	}

	private void tickClient(Player player) {
		if (!player.onGround() && player.getDeltaMovement().y() > 0 && !jumpedRecently(player)) {
			lastJumpTracker.put(player.getId(), player.level().getGameTime());
		}
		if (player.isSecondaryUseActive()) {
			if (!player.onGround() && player.getDeltaMovement().y() > -8 && !jumpedRecently(player)) {
				player.addDeltaMovement(DOWNWARD_MOVEMENT);
			}
			WorldHelper.repelEntitiesSWRG(player.level(), player.getBoundingBox().inflate(3.5), player);
		}
	}

	/**
	 * Client only holder for logic that must not be class loaded on a dedicated server.
	 */
	private static class ClientHelper {

		private static boolean registered;

		private static void register() {
			if (!registered) {
				registered = true;
				net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientTickEvents.START_CLIENT_TICK.register(ClientHelper::onStartTick);
			}
		}

		private static void onStartTick(Minecraft client) {
			LocalPlayer player = client.player;
			if (player != null && player.level().isClientSide() && player.getItemBySlot(EquipmentSlot.LEGS).getItem() instanceof GemLegs legs) {
				legs.tickClient(player);
			}
		}
	}
}
