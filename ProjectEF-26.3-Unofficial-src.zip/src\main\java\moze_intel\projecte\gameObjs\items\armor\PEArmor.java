package moze_intel.projecte.gameObjs.items.armor;

import net.minecraft.core.component.DataComponents;
import net.minecraft.world.damagesource.DamageSource;
import net.minecraft.world.entity.EquipmentSlot;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.equipment.ArmorMaterial;
import net.minecraft.world.item.equipment.ArmorType;
import net.minecraft.world.item.equipment.Equippable;
import org.jetbrains.annotations.Nullable;

public abstract class PEArmor extends Item {

	private final ArmorType type;

	protected PEArmor(ArmorMaterial material, ArmorType armorPiece, Properties props) {
		//Note: We don't use Item.Properties#humanoidArmor as our materials have a durability of zero. That method also adds the MAX_DAMAGE and DAMAGE
		// components which with a durability of zero would make the armor count as broken and get destroyed by the first bit of damage it takes.
		// Instead we add the components it would add minus the durability related ones, which also makes the pieces non enchantable just like the
		// 1.21.1 versions that overrode Item#isEnchantable to return false (in 26.3 an absent ENCHANTABLE component is what makes an item non enchantable).
		super(armorProperties(material, armorPiece, props));
		this.type = armorPiece;
	}

	private static Properties armorProperties(ArmorMaterial material, ArmorType armorPiece, Properties props) {
		Properties properties = props.stacksTo(1)
				.attributes(material.createAttributes(armorPiece))
				.component(DataComponents.EQUIPPABLE, Equippable.builder(armorPiece.getSlot())
						.setEquipSound(material.equipSound())
						.setAsset(material.assetId())
						.build());
		if (material.repairIngredient() != null) {
			properties = properties.repairable(material.repairIngredient());
		}
		return properties;
	}

	public ArmorType getType() {
		return type;
	}

	/**
	 * Minimum percent damage will be reduced to if the full set is worn
	 */
	public abstract float getFullSetBaseReduction();

	/**
	 * Gets the max damage that a piece of this armor in a given slot can absorb of a specific type.
	 *
	 * @apiNote A value of zero means that there is no special bonus blocking powers for that damage type, and the piece's base reduction will be get used instead by the
	 * damage calculation event.
	 */
	public abstract float getMaxDamageAbsorb(ArmorType type, DamageSource source);

	public ReductionInfo getReductionInfo(DamageSource source) {
		float maxDamageAbsorb = getMaxDamageAbsorb(type, source);
		float fullSetReduction = getFullSetBaseReduction();
		if (maxDamageAbsorb > 0 && fullSetReduction > 0) {
			float pieceEffectiveness = getPieceEffectiveness(type);
			return new ReductionInfo(fullSetReduction * pieceEffectiveness, maxDamageAbsorb * pieceEffectiveness);
		}
		return ReductionInfo.ZERO;
	}

	/**
	 * Gets the overall effectiveness of a given slots piece.
	 */
	public float getPieceEffectiveness(ArmorType type) {
		return switch (type) {
			case BOOTS, HELMET -> 0.2F;
			case CHESTPLATE, LEGGINGS -> 0.3F;
			default -> 0;
		};
	}

	/**
	 * Checks if the passed equipment slot is one that humanoid armor gets ticked in. The slot an item is ticked in is only non-null when the item is actually equipped
	 * (or in the selected hotbar slot) rather than just somewhere in the player's inventory.
	 */
	protected static boolean isArmorSlot(@Nullable EquipmentSlot slot) {
		return slot != null && slot.getType() == EquipmentSlot.Type.HUMANOID_ARMOR;
	}

	public record ReductionInfo(float percentReduced, float maxDamagedAbsorbed) {

		public static final ReductionInfo ZERO = new ReductionInfo(0, 0);

		public ReductionInfo add(ReductionInfo other) {
			if (this == ZERO) {
				return other;
			} else if (other == ZERO) {
				return this;
			}
			return new ReductionInfo(percentReduced + other.percentReduced, maxDamagedAbsorbed + other.maxDamagedAbsorbed);
		}
	}
}
