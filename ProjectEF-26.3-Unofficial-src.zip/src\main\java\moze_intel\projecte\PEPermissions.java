package moze_intel.projecte;

import java.util.function.Predicate;
import net.fabricmc.fabric.api.permission.v1.PermissionContextOwner;
import net.fabricmc.fabric.api.permission.v1.PermissionNode;
import net.minecraft.commands.CommandSourceStack;
import net.minecraft.commands.Commands;
import net.minecraft.server.permissions.PermissionCheck;
import net.minecraft.server.permissions.PermissionLevel;

/**
 * Permission nodes for the ProjectEF commands, checked through the fabric permissions api (falling back to the given vanilla permission level when no permission
 * mod is installed).
 */
public class PEPermissions {

	//Commands
	public static final CommandPermissionNode COMMAND = new CommandPermissionNode(node("command"), PermissionLevel.ALL, Commands.LEVEL_ALL);

	public static final CommandPermissionNode COMMAND_REMOVE_EMC = nodeOpCommand("remove_emc");
	public static final CommandPermissionNode COMMAND_RESET_EMC = nodeOpCommand("reset_emc");
	public static final CommandPermissionNode COMMAND_SET_EMC = nodeOpCommand("set_emc");
	public static final CommandPermissionNode COMMAND_SHOW_BAG = nodeOpCommand("show_bag");
	public static final CommandPermissionNode COMMAND_EMC = nodeOpCommand("emc");
	public static final CommandPermissionNode COMMAND_EMC_ADD = nodeSubCommand(COMMAND_EMC, "add");
	public static final CommandPermissionNode COMMAND_EMC_REMOVE = nodeSubCommand(COMMAND_EMC, "remove");
	public static final CommandPermissionNode COMMAND_EMC_SET = nodeSubCommand(COMMAND_EMC, "set");
	public static final CommandPermissionNode COMMAND_EMC_TEST = nodeSubCommand(COMMAND_EMC, "test");
	public static final CommandPermissionNode COMMAND_EMC_GET = nodeSubCommand(COMMAND_EMC, "get");
	public static final CommandPermissionNode COMMAND_KNOWLEDGE = nodeOpCommand("knowledge");
	public static final CommandPermissionNode COMMAND_KNOWLEDGE_CLEAR = nodeSubCommand(COMMAND_KNOWLEDGE, "clear");
	public static final CommandPermissionNode COMMAND_KNOWLEDGE_LEARN = nodeSubCommand(COMMAND_KNOWLEDGE, "learn");
	public static final CommandPermissionNode COMMAND_KNOWLEDGE_UNLEARN = nodeSubCommand(COMMAND_KNOWLEDGE, "unlearn");
	public static final CommandPermissionNode COMMAND_KNOWLEDGE_TEST = nodeSubCommand(COMMAND_KNOWLEDGE, "test");

	private static PermissionNode<Boolean> node(String nodeName) {
		return PermissionNode.of(PECore.MODID, nodeName);
	}

	private static CommandPermissionNode nodeOpCommand(String nodeName) {
		return new CommandPermissionNode(node("command." + nodeName), PermissionLevel.GAMEMASTERS, Commands.LEVEL_GAMEMASTERS);
	}

	private static CommandPermissionNode nodeSubCommand(CommandPermissionNode parent, String nodeName) {
		//Because sub commands can assume that the parent was checked before getting to them, permission mods can grant
		// the parent node; the sub node only exists in case someone wants to do more restricting
		return new CommandPermissionNode(PermissionNode.of(PECore.MODID, parent.node().key().getPath() + "." + nodeName),
				parent.fallbackLevel(), parent.fallbackCheck());
	}

	public record CommandPermissionNode(PermissionNode<Boolean> node, PermissionLevel fallbackLevel, PermissionCheck fallbackCheck) implements Predicate<CommandSourceStack> {

		@Override
		public boolean test(CommandSourceStack source) {
			PermissionContextOwner owner = source instanceof PermissionContextOwner fromSource ? fromSource : null;
			if (owner == null && source.getEntity() instanceof PermissionContextOwner fromEntity) {
				owner = fromEntity;
			}
			if (owner != null) {
				//Let permission mods decide, falling back to the vanilla level when they do not handle the node
				return owner.checkPermission(node.key(), fallbackLevel);
			}
			return fallbackCheck.check(source.permissions());
		}
	}
}
