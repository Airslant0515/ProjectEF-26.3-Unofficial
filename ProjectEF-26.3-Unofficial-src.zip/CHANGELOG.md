# Changelog

All notable changes to this **unofficial** 26.3 port are documented here.
The port is based on ProjectEF 1.3.1 (Minecraft 1.21.1); numbers below refer to
this repository, not to upstream releases.

## [1.3.1-26.3] - 2026-11-22

First public build of the Minecraft **26.3 / Fabric Loader 0.20.1** port.

### Ported

- Full EMC engine (mappers, custom conversions, world transmutation data) on the 26.3
  recipe/registry APIs, including the new data-driven `BrewingRecipe` lookup that
  replaced the removed `PotionBrewing`.
- Transmutation table / tablet, collectors, relays, condensers, alchemical bags,
  dark/red matter tools and armour, rings, Philo Stone, Time Watch, etc.
- Data-driven armour (`assets/projecte/equipment/*.json` + humanoid equipment textures)
  with the original "no durability, no enchantability" behaviour preserved.
- New 26.3 item model definitions (`assets/projecte/items/*.json`) using
  `minecraft:condition` / `minecraft:range_dispatch` instead of the removed
  `overrides` array, backed by custom `projecte:active` / `projecte:mode` item
  model properties.
- GUI rewritten for `GuiGraphicsExtractor` (`extractRenderState` / `extractBackground`
  / `extractLabels` / `extractSlot`), plus `MouseButtonEvent` / `ContainerInput` /
  `InputConstants` input handling.
- Rendering rewritten on the new render pipeline system (`renderpearl`):
  sprite, YEU and transmutation-overlay pipelines are registered during client init.
- Recipe, advancement and `pe_world_transmutations` data migrated to 26.3 formats
  (HolderSet ingredients, `recipes` advancement key, `id`/`properties` block states).
- Config moved to Forge Config API Port **v5** (`fuzs.forgeconfigapiport.fabric.api.v5`),
  and the list-typed `highAlchemistUUIDs` option no longer rewrites `common.toml` in a loop.
- Permissions use Fabric API's `fabric-permission-api-v1` instead of the removed
  LuckPerms-based API.
- Creative tab, fuel values (`DataComponents.COOKING_FUEL`) and item group events
  updated to the renamed 26.3 Fabric API modules.

### Removed (no 26.3 equivalent)

- Trinkets integration — rings and other curios now work from the hotbar / offhand.
- EMI, REI and WTHIT integrations. JEI and Jade integrations are kept.

### Fixed

- `PEDataComponents` crashed on first use (`Holder$Reference` was cast to
  `DataComponentType`; `Holder.Reference#value()` is now used).
- Update checker no longer blocks JVM shutdown: daemon thread, 5 s connect/read
  timeouts and a bounded retry count.
- Collector no longer drops its locked "ghost" stack when broken
  (`preRemoveSideEffects` override).
- `ToolMaterial` enchantment value of 0 no longer crashes item registration.
- Item models of `alchemical_chest`, `condenser_mk1` and `condenser_mk2` now declare
  a particle texture.
- Missing `key.category.projecte.main` translation key added.

### Verified

- Dedicated server and client start, world creation, save and reload.
- Full 26-mod instance (Sodium, Iris, FerriteCore, ImmediatelyFast, EntityCulling,
  JEI, Jade, Xaero, Tom's Storage, spark, …): no crashes, no mixin conflicts,
  20 TPS sustained.
