package moze_intel.projecte.gameObjs.registration;

import com.mojang.datafixers.util.Either;
import java.util.Optional;
import java.util.function.Predicate;
import java.util.function.Supplier;
import java.util.stream.Stream;
import net.minecraft.core.Holder;
import net.minecraft.core.HolderOwner;
import net.minecraft.core.Registry;
import net.minecraft.core.component.DataComponentMap;
import net.minecraft.resources.Identifier;
import net.minecraft.resources.ResourceKey;
import net.minecraft.tags.TagKey;
import org.jetbrains.annotations.NotNull;
import org.jetbrains.annotations.Nullable;

/**
 * A lazily bound holder for a registry object. Mirrors the behavior the NeoForge DeferredHolder used to provide: created up front, bound when the owning
 * {@link PEDeferredRegister} performs the actual registration against the vanilla registry.
 *
 * <p>{@link Holder} is sealed in modern versions, but {@link Holder.Reference} is not, so this extends the reference implementation directly. Until the holder gets
 * bound it behaves like an unbound reference: it knows its {@link ResourceKey}, but accessing the value or the tags fails with a helpful message.</p>
 */
public class PEDeferredHolder<R, T extends R> extends Holder.Reference<R> implements INamedEntry, Supplier<T> {

	private final ResourceKey<R> key;
	@Nullable
	private T value;
	@Nullable
	private Holder.Reference<R> reference;

	public PEDeferredHolder(ResourceKey<? extends Registry<R>> registryKey, Identifier valueName) {
		this(ResourceKey.create(registryKey, valueName));
	}

	public PEDeferredHolder(ResourceKey<R> key) {
		super(Type.STAND_ALONE, null, key, null);
		this.key = key;
	}

	/**
	 * Binds this holder to the registered value. Called by {@link PEDeferredRegister} when registration is performed.
	 */
	void bind(T value, Holder.Reference<R> reference) {
		this.value = value;
		this.reference = reference;
		super.bindValue(value);
	}

	protected Holder.Reference<R> boundReference() {
		if (reference == null) {
			throw new IllegalStateException("Registry object not present: " + key + ". Was the owning register's register() method called yet?");
		}
		return reference;
	}

	/**
	 * @return The registered value.
	 */
	@Override
	public T get() {
		return value();
	}

	@NotNull
	@Override
	public T value() {
		if (value == null) {
			throw new IllegalStateException("Registry object not present: " + key + ". Was the owning register's register() method called yet?");
		}
		return value;
	}

	public Identifier getId() {
		return key.identifier();
	}

	public ResourceKey<R> getKey() {
		return key;
	}

	public Optional<T> asOptional() {
		return Optional.ofNullable(value);
	}

	@Override
	public String getName() {
		return getId().getPath();
	}

	@Override
	public boolean isBound() {
		return value != null;
	}

	@Override
	public boolean areComponentsBound() {
		return reference != null && reference.areComponentsBound();
	}

	@Override
	public boolean is(@NotNull Identifier id) {
		return id.equals(key.identifier());
	}

	@Override
	public boolean is(@NotNull ResourceKey<R> key) {
		return key == this.key;
	}

	@Override
	public boolean is(@NotNull Predicate<ResourceKey<R>> predicate) {
		return predicate.test(key);
	}

	@Override
	public boolean is(@NotNull TagKey<R> tag) {
		return boundReference().is(tag);
	}

	@Override
	public boolean is(@NotNull Holder<R> holder) {
		return holder.is(key.identifier());
	}

	@NotNull
	@Override
	public Stream<TagKey<R>> tags() {
		return boundReference().tags();
	}

	@NotNull
	@Override
	public DataComponentMap components() {
		return boundReference().components();
	}

	@NotNull
	@Override
	public Either<ResourceKey<R>, R> unwrap() {
		return Either.left(key);
	}

	@NotNull
	@Override
	public Optional<ResourceKey<R>> unwrapKey() {
		return Optional.of(key);
	}

	@NotNull
	@Override
	public Kind kind() {
		return Kind.REFERENCE;
	}

	@Override
	public boolean canSerializeIn(@NotNull HolderOwner<R> owner) {
		return reference != null && reference.canSerializeIn(owner);
	}

	@Override
	public boolean equals(Object obj) {
		return obj == this || obj instanceof PEDeferredHolder<?, ?> other && other.key == this.key;
	}

	@Override
	public int hashCode() {
		return key.hashCode();
	}

	@Override
	public String toString() {
		return "PEDeferredHolder{" + key + "}";
	}
}
