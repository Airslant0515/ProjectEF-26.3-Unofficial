package moze_intel.projecte.rendering;

import com.mojang.blaze3d.vertex.PoseStack;
import com.mojang.blaze3d.vertex.VertexConsumer;
import com.mojang.math.Axis;
import java.util.UUID;
import moze_intel.projecte.PECore;
import net.fabricmc.loader.api.FabricLoader;
import net.minecraft.client.Minecraft;
import net.minecraft.client.model.player.PlayerModel;
import net.minecraft.client.renderer.SubmitNodeCollector;
import net.minecraft.client.renderer.entity.RenderLayerParent;
import net.minecraft.client.renderer.entity.layers.RenderLayer;
import net.minecraft.client.renderer.entity.state.AvatarRenderState;
import net.minecraft.client.renderer.rendertype.RenderType;
import net.minecraft.resources.Identifier;
import net.minecraft.util.Mth;
import net.minecraft.world.entity.Pose;
import net.minecraft.world.entity.player.Player;
import org.jetbrains.annotations.NotNull;
import org.jetbrains.annotations.Nullable;

public class LayerYue extends RenderLayer<AvatarRenderState, PlayerModel> {

	private static final UUID SIN_UUID = UUID.fromString("5f86012c-ca4b-451a-989c-8fab167af647");
	private static final UUID CLAR_UUID = UUID.fromString("e5c59746-9cf7-4940-a849-d09e1f1efc13");
	private static final Identifier HEART_LOC = PECore.rl("textures/models/heartcircle.png");
	private static final Identifier YUE_LOC = PECore.rl("textures/models/yuecircle.png");

	public LayerYue(RenderLayerParent<AvatarRenderState, PlayerModel> renderer) {
		super(renderer);
	}

	@Override
	public void submit(@NotNull PoseStack matrix, @NotNull SubmitNodeCollector collector, int light, @NotNull AvatarRenderState state,
			float limbSwing, float limbSwingAmount) {
		if (state.isInvisible) {
			return;
		}
		UUID uuid = getPlayerUUID(state);
		if (!FabricLoader.getInstance().isDevelopmentEnvironment() && !SIN_UUID.equals(uuid) && !CLAR_UUID.equals(uuid)) {
			return;
		}
		matrix.pushPose();
		getParentModel().body.translateAndRotate(matrix);
		double yShift = -0.498;
		if (state.hasPose(Pose.CROUCHING)) {
			//Only modify where it renders if the player's pose is crouching
			matrix.rotate(Axis.XN.rotation(0.5F));
			yShift = -0.44;
		}
		matrix.rotate(Axis.ZP.rotation(Mth.PI));
		matrix.scale(3, 3, 3);
		matrix.translate(-0.5, yShift, -0.5);
		RenderType renderType = PERenderType.YEU_RENDERER.apply(CLAR_UUID.equals(uuid) ? HEART_LOC : YUE_LOC);
		collector.submitCustomGeometry(matrix, renderType, LayerYue::renderDisc);
		matrix.popPose();
	}

	private static void renderDisc(PoseStack.Pose pose, VertexConsumer builder) {
		builder.addVertex(pose, 0, 0, 0).setUv(0, 0).setColor(0, 255, 0, 255);
		builder.addVertex(pose, 0, 0, 1).setUv(0, 1).setColor(0, 255, 0, 255);
		builder.addVertex(pose, 1, 0, 1).setUv(1, 1).setColor(0, 255, 0, 255);
		builder.addVertex(pose, 1, 0, 0).setUv(1, 0).setColor(0, 255, 0, 255);
	}

	@Nullable
	private static UUID getPlayerUUID(AvatarRenderState state) {
		Minecraft minecraft = Minecraft.getInstance();
		if (minecraft.level != null && minecraft.level.getEntity(state.id) instanceof Player player) {
			return player.getUUID();
		}
		return null;
	}
}