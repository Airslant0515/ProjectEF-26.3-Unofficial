package moze_intel.projecte.rendering;

import com.mojang.renderpearl.api.pipeline.ColorTargetState;
import com.mojang.renderpearl.api.pipeline.CompareOp;
import com.mojang.renderpearl.api.pipeline.DepthStencilState;
import com.mojang.renderpearl.api.pipeline.RenderPipeline;
import java.util.function.Function;
import moze_intel.projecte.PECore;
import net.minecraft.client.renderer.RenderPipelines;
import net.minecraft.client.renderer.rendertype.RenderSetup;
import net.minecraft.client.renderer.rendertype.RenderSetup.OutlineProperty;
import net.minecraft.client.renderer.rendertype.RenderType;
import net.minecraft.resources.Identifier;
import net.minecraft.util.Util;

public class PERenderType {

	//Note: Pipelines have to be known to the renderer before the first resource reload happens, as that is when they get compiled.
	// As such they are registered as soon as this class gets loaded which is why init() needs to be called from client initialization.
	private static final RenderPipeline SPRITE_PIPELINE = RenderPipelines.register(
			RenderPipeline.builder(RenderPipelines.GUI_TEXTURED_SNIPPET)
					.withLocation(PECore.rl("pipeline/sprite_renderer"))
					.withColorTargetState(ColorTargetState.DEFAULT)
					.withDepthStencilState(DepthStencilState.DEFAULT)
					.build()
	);
	//The old render type this replaces was a position_tex_color render type with translucent blending, no culling, and the default depth test
	private static final RenderPipeline YEU_PIPELINE = RenderPipelines.register(
			RenderPipeline.builder(RenderPipelines.GUI_TEXTURED_SNIPPET)
					.withLocation(PECore.rl("pipeline/yeu_renderer"))
					.withDepthStencilState(DepthStencilState.DEFAULT)
					.withCull(false)
					.build()
	);
	private static final RenderPipeline TRANSMUTATION_OVERLAY_PIPELINE = RenderPipelines.register(
			RenderPipeline.builder(RenderPipelines.DEBUG_FILLED_SNIPPET)
					.withLocation(PECore.rl("pipeline/transmutation_overlay"))
					//Offset it so that it can render properly on top of the blocks it is highlighting
					.withDepthStencilState(new DepthStencilState(CompareOp.GREATER_THAN_OR_EQUAL, false, 1.0F, 10.0F))
					.build()
	);

	public static final Function<Identifier, RenderType> SPRITE_RENDERER = Util.memoize(texture -> RenderType.create(
			"projecte_sprite_renderer",
			RenderSetup.builder(SPRITE_PIPELINE)
					.withTexture("Sampler0", texture)
					.affectsCrumbling()
					.setOutline(OutlineProperty.AFFECTS_OUTLINE)
					.createRenderSetup()
	));
	public static final Function<Identifier, RenderType> YEU_RENDERER = Util.memoize(texture -> RenderType.create(
			"projecte_yeu_renderer",
			RenderSetup.builder(YEU_PIPELINE)
					.withTexture("Sampler0", texture)
					.createRenderSetup()
	));
	public static final RenderType TRANSMUTATION_OVERLAY = RenderType.create(
			"projecte_transmutation_overlay",
			RenderSetup.builder(TRANSMUTATION_OVERLAY_PIPELINE)
					.setOitPipelines(RenderPipelines.OIT_DEBUG_QUADS)
					.affectsCrumbling()
					.createRenderSetup()
	);

	private PERenderType() {
	}

	/**
	 * Ensures this class gets loaded, and thereby that our pipelines get registered before the first resource reload compiles the required pipelines.
	 */
	public static void init() {
	}
}