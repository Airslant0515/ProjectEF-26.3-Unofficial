package moze_intel.projecte.rendering;

import com.mojang.blaze3d.vertex.PoseStack;
import com.mojang.math.Axis;
import moze_intel.projecte.gameObjs.block_entities.EmcChestBlockEntity;
import moze_intel.projecte.gameObjs.registration.impl.BlockRegistryObject;
import net.minecraft.client.model.geom.ModelLayers;
import net.minecraft.client.model.object.chest.ChestModel;
import net.minecraft.client.renderer.SubmitNodeCollector;
import net.minecraft.client.renderer.blockentity.BlockEntityRenderer;
import net.minecraft.client.renderer.blockentity.BlockEntityRendererProvider;
import net.minecraft.client.renderer.blockentity.state.BlockEntityRenderState;
import net.minecraft.client.renderer.feature.ModelFeatureRenderer.CrumblingOverlay;
import net.minecraft.client.renderer.rendertype.RenderType;
import net.minecraft.client.renderer.rendertype.RenderTypes;
import net.minecraft.client.renderer.state.level.CameraRenderState;
import net.minecraft.client.renderer.texture.OverlayTexture;
import net.minecraft.resources.Identifier;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.level.block.state.properties.BlockStateProperties;
import net.minecraft.world.phys.Vec3;
import org.jetbrains.annotations.NotNull;
import org.jetbrains.annotations.Nullable;

//Only used on the client
// [VanillaCopy] Adapted from ChestRenderer
public class ChestRenderer implements BlockEntityRenderer<EmcChestBlockEntity, ChestRenderer.ChestRenderState> {

	private final ChestModel model;
	private final BlockRegistryObject<?, ?> type;
	private final RenderType renderType;

	public ChestRenderer(BlockEntityRendererProvider.Context context, Identifier texture, BlockRegistryObject<?, ?> type) {
		this.renderType = RenderTypes.entityCutout(texture);
		this.type = type;
		this.model = new ChestModel(context.bakeLayer(ModelLayers.CHEST));
	}

	@NotNull
	@Override
	public ChestRenderState createRenderState() {
		return new ChestRenderState();
	}

	@Override
	public void extractRenderState(@NotNull EmcChestBlockEntity chest, @NotNull ChestRenderState state, float partialTick,
			@NotNull Vec3 cameraPosition, @Nullable CrumblingOverlay breakProgress) {
		BlockEntityRenderer.super.extractRenderState(chest, state, partialTick, cameraPosition, breakProgress);
		state.yRot = 0;
		if (chest.getLevel() != null && !chest.isRemoved()) {
			BlockState blockState = chest.getLevel().getBlockState(chest.getBlockPos());
			if (blockState.is(this.type.getBlock())) {
				state.yRot = -blockState.getValue(BlockStateProperties.HORIZONTAL_FACING).toYRot();
			}
		}
		float lidAngle = 1.0F - chest.getOpenNess(partialTick);
		state.lidAngle = 1.0F - lidAngle * lidAngle * lidAngle;
	}

	@Override
	public void submit(@NotNull ChestRenderState state, @NotNull PoseStack matrix, @NotNull SubmitNodeCollector collector, @NotNull CameraRenderState camera) {
		matrix.pushPose();
		matrix.translate(0.5, 0.5, 0.5);
		matrix.rotate(Axis.YP.rotationDegrees(state.yRot));
		matrix.translate(-0.5, -0.5, -0.5);
		collector.submitModel(this.model, state.lidAngle, matrix, this.renderType, state.lightCoords, OverlayTexture.NO_OVERLAY, 0);
		if (state.breakProgress != null) {
			collector.order(1).submitCrumblingOverlay(this.model, state.lidAngle, matrix, this.renderType, state.lightCoords, OverlayTexture.NO_OVERLAY, -1,
					state.breakProgress);
		}
		matrix.popPose();
	}

	public static class ChestRenderState extends BlockEntityRenderState {

		private float yRot;
		private float lidAngle;
	}
}