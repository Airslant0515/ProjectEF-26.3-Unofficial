package moze_intel.projecte.emc.mappers.recipe;

import com.mojang.logging.LogUtils;
import it.unimi.dsi.fastutil.objects.Object2IntArrayMap;
import it.unimi.dsi.fastutil.objects.Object2IntMap;
import it.unimi.dsi.fastutil.objects.Object2IntOpenHashMap;
import java.util.ArrayList;
import java.util.Collection;
import java.util.List;
import java.util.Optional;
import java.util.stream.Stream;
import moze_intel.projecte.PECore;
import moze_intel.projecte.api.mapper.collector.IMappingCollector;
import moze_intel.projecte.api.mapper.recipe.INSSFakeGroupManager;
import moze_intel.projecte.api.mapper.recipe.INSSFakeGroupManager.FakeGroupData;
import moze_intel.projecte.api.mapper.recipe.IRecipeTypeMapper;
import moze_intel.projecte.api.nss.NSSItem;
import moze_intel.projecte.api.nss.NormalizedSimpleStack;
import moze_intel.projecte.utils.Constants;
import net.fabricmc.fabric.api.recipe.v1.ingredient.CustomIngredient;
import net.minecraft.core.Holder.Reference;
import net.minecraft.core.RegistryAccess;
import net.minecraft.core.component.DataComponents;
import net.minecraft.core.registries.BuiltInRegistries;
import net.minecraft.core.registries.Registries;
import net.minecraft.resources.Identifier;
import net.minecraft.util.context.ContextMap;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.ItemStackTemplate;
import net.minecraft.world.item.Items;
import net.minecraft.world.item.crafting.CraftingRecipe;
import net.minecraft.world.item.crafting.DyeRecipe;
import net.minecraft.world.item.crafting.ImbueRecipe;
import net.minecraft.world.item.crafting.Ingredient;
import net.minecraft.world.item.crafting.Recipe;
import net.minecraft.world.item.crafting.RecipeHolder;
import net.minecraft.world.item.crafting.SmithingRecipe;
import net.minecraft.world.item.crafting.SmithingTrimRecipe;
import net.minecraft.world.item.crafting.TransmuteRecipe;
import net.minecraft.world.item.crafting.display.RecipeDisplay;
import net.minecraft.world.item.crafting.display.SlotDisplay.Composite;
import net.minecraft.world.item.crafting.display.SlotDisplayContext;
import net.minecraft.world.item.equipment.trim.ArmorTrim;
import net.minecraft.world.item.equipment.trim.TrimMaterial;
import net.minecraft.world.item.equipment.trim.TrimMaterials;
import net.minecraft.world.item.equipment.trim.TrimPattern;
import net.minecraft.world.level.block.Block;
import net.minecraft.world.level.block.ShulkerBoxBlock;
import org.jetbrains.annotations.Nullable;

//TODO: Fix recipe mapping for things containing EMC not working properly? (aka full klein stars)
// We probably could do it with a set value before, make it a grouping of a fake stack that has
// a specific emc value, and it, and then use that? We probably should check the capability for
// it though it might be enough for now to just use an instanceof?
//TODO: Evaluate using a fake crafting inventory and then calling recipe#getRemainingItems? May not be worthwhile to do
// The bigger question is how would the "fake group" stuff work for it? Maybe have an NSSFake called "inverted" that
// gets thrown in with a bucket? Or conversion NSSFake # = inverted + thing
// Alternatively we should have the fake group manager keep track of an intermediary object that says what kind
// of transformations actually is happening so that we can then basically compare sets/easier allow for custom objects
// to do things
//TODO: Do we want to somehow expose this class as a helper in the api?
public abstract class BaseRecipeTypeMapper implements IRecipeTypeMapper {

	@Override
	public boolean handleRecipe(IMappingCollector<NormalizedSimpleStack, Long> mapper, RecipeHolder<?> recipeHolder, RegistryAccess registryAccess,
			INSSFakeGroupManager fakeGroupManager) {
		Recipe<?> recipe = recipeHolder.value();
		ItemStack recipeOutput = getResult(recipe, registryAccess);
		if (recipeOutput.isEmpty()) {
			//If there is no output (for example a special recipe), don't mark it that we handled it
			return false;
		} else if (!canMap(recipe, recipeOutput)) {
			//Skip handling of any "special" recipes as they might have issues if we try to handle them
			return false;
		}
		Collection<Ingredient> ingredientsChecked = getIngredientsChecked(recipeHolder);
		if (ingredientsChecked == null) {
			//Failed to get matching ingredients, bail but mark that we handled it as there is a 99% chance a later
			// mapper would fail as well due to it being an invalid recipe
			return true;
		} else if (ingredientsChecked.isEmpty()) {
			//Recipes without any ingredients can't be mapped, but we mark them as handled so that they don't get retried
			return true;
		}
		Identifier recipeID = recipeHolder.id().identifier();
		ContextMap context = displayContext(registryAccess);
		Object2IntMap<NormalizedSimpleStack> ingredientMap = new Object2IntOpenHashMap<>();
		for (Ingredient recipeItem : ingredientsChecked) {
			if (recipeItem.isEmpty()) {
				//Skip any explicitly empty ingredients as they are just used for spacing
				continue;
			}
			List<ItemStack> matches = getMatchingStacks(recipeItem, recipeID, context);
			if (matches.isEmpty()) {
				//If we don't have any matches for the ingredient just return that we handled it, as if it is an accidentally empty ingredient,
				// or we failed to get the matching ingredients, nothing will be able to handle it. If it was explicitly empty,
				// then it will be skipped above
				return true;
			} else if (matches.size() == 1) {
				//Handle this ingredient as a direct representation of the stack it represents
				ItemStack match = matches.getFirst();
				if (match.isEmpty()) {
					//If we don't have any matches for the ingredient just return that we couldn't handle it,
					// given a later recipe might be able to
					return false;
				} else if (addIngredient(ingredientMap, match, recipeID)) {
					//Failed to add ingredient, bail but mark that we handled it as there is a 99% chance a later
					// mapper would fail as well due to it being an invalid recipe
					return true;
				}
			} else {
				Object2IntMap<NormalizedSimpleStack> rawNSSMatches = new Object2IntOpenHashMap<>(matches.size());
				List<ItemStack> stacks = new ArrayList<>(matches.size());
				for (ItemStack match : matches) {
					if (!match.isEmpty()) {
						//Validate it is not an empty stack in case mods do weird things in custom ingredients
						// Note: We don't have to worry about duplicates, as getStacks returns a distinct set of items
						rawNSSMatches.put(NSSItem.createItem(match), 1);
						stacks.add(match);
					}
				}
				int count = stacks.size();
				if (count == 0) {
					//If we don't have any matches for the ingredient just return that we handled it, as if it is an accidentally empty ingredient,
					// nothing will be able to handle it. If it was explicitly empty, then it will be skipped above
					return true;
				} else if (count > 1) {
					//Handle this ingredient as the representation of all the stacks it supports
					FakeGroupData group = fakeGroupManager.getOrCreateFakeGroupDirect(rawNSSMatches, true, true);
					NormalizedSimpleStack dummy = group.dummy();
					ingredientMap.mergeInt(dummy, 1, Constants.INT_SUM);
					if (group.created()) {
						//Only lookup the matching stacks for the group with conversion if we don't already have
						// a group created for this dummy ingredient
						// Note: We soft ignore cases where it fails/there are no matching group ingredients
						// as then our fake ingredient will never actually have an emc value assigned with it
						// so the recipe won't either
						boolean success = false;
						for (ItemStack stack : stacks) {
							//Note: We use a capacity of two as it will only contain the stack itself and potentially a container
							Object2IntMap<NormalizedSimpleStack> groupIngredientMap = new Object2IntArrayMap<>(2);
							//Copy the stack to ensure a mod that is implemented poorly doesn't end up changing
							// the source stack in the recipe
							if (!addIngredient(groupIngredientMap, stack, recipeID)) {
								mapper.addConversion(1, dummy, groupIngredientMap);
								success = true;
							}
						}
						if (!success) {
							//Failed to add any of the ingredients, bail but mark that we handled it as there is a 99% chance a later
							// mapper would fail as well due to it being an invalid recipe
							return true;
						}
					}
				} else if (addIngredient(ingredientMap, stacks.getFirst(), recipeID)) {//There is only actually one non-empty ingredient
					//Failed to add ingredient, bail but mark that we handled it as there is a 99% chance a later
					// mapper would fail as well due to it being an invalid recipe
					return true;
				}
			}
		}
		mapper.addConversion(recipeOutput.getCount(), NSSItem.createItem(recipeOutput), ingredientMap);
		return true;
	}

	public static ContextMap displayContext(RegistryAccess registryAccess) {
		return ContextMap.builder().set(SlotDisplayContext.REGISTRIES, registryAccess).buildAndValidate(SlotDisplayContext.CONTEXT);
	}

	public static List<ItemStack> getStacks(Ingredient ingredient, ContextMap context) {
		CustomIngredient customIngredient = ingredient.getCustomIngredient();
		if (customIngredient != null) {
			//Note: Try to resolve the display of the custom ingredient first, as it may be more accurate than the items it matches
			List<ItemStack> stacks = ingredient.display().resolveForStacks(context).stream().filter(customIngredient::test).toList();
			if (!stacks.isEmpty()) {
				return stacks;
			}
		}
		return ingredient.items().distinct().map(ItemStack::new).toList();
	}

	public static ItemStack getResult(Recipe<?> recipe, RegistryAccess registryAccess) {
		if (recipe instanceof SmithingTrimRecipe) {
			//Note: Trims don't have a result, so we create an example one to determine the emc value of
			return createExampleTrim(registryAccess);
		}
		List<RecipeDisplay> displays = recipe.display();
		if (displays.isEmpty() || isKeepInputTransmute(recipe)) {
			//If there is no display for the recipe, or it is a transmute recipe that keeps its input, it has no output to map
			return ItemStack.EMPTY;
		}
		return displays.getLast().result().resolveForFirstStack(displayContext(registryAccess));
	}

	public static boolean isKeepInputTransmute(Recipe<?> recipe) {
		//Composite displays mean that the transmute recipe keeps the input, and only changes the components of it
		return recipe instanceof TransmuteRecipe && !recipe.display().isEmpty() && recipe.display().getLast().result() instanceof Composite;
	}

	private static ItemStack createExampleTrim(RegistryAccess registryAccess) {
		ItemStack stack = new ItemStack(Items.IRON_CHESTPLATE);
		Optional<Reference<TrimPattern>> pattern = registryAccess.lookupOrThrow(Registries.TRIM_PATTERN).listElements().findFirst();
		Optional<Reference<TrimMaterial>> material = registryAccess.lookupOrThrow(Registries.TRIM_MATERIAL).get(TrimMaterials.REDSTONE);
		if (pattern.isPresent() && material.isPresent()) {
			stack.set(DataComponents.TRIM, new ArmorTrim(material.get(), pattern.get()));
		}
		return stack;
	}

	protected boolean canMap(Recipe<?> recipe, ItemStack output) {
		if (recipe.isSpecial() || recipe instanceof DyeRecipe || recipe instanceof ImbueRecipe) {
			//Skip handling of any "special" recipes as they might have issues if we try to handle them,
			// and skip dying/imbuing as the mappings are handled by the specific mappers and component processors
			return false;
		} else if (recipe instanceof CraftingRecipe && output.is(Items.SUSPICIOUS_STEW)) {
			//Suspicious stew has its emc value calculated based on the effects it has, so we skip mapping the crafting recipe
			return false;
		}
		//If the output is a shulker box, then the transmute recipe is just recoloring it, which is handled by the shulker
		// recoloring mapper as the input is kept
		return !(recipe instanceof TransmuteRecipe) || !(Block.byItem(output.getItem()) instanceof ShulkerBoxBlock);
	}

	private List<ItemStack> getMatchingStacks(Ingredient ingredient, Identifier recipeID, ContextMap context) {
		try {
			return getStacks(ingredient, context);
		} catch (Exception e) {
			CustomIngredient customIngredient = ingredient.getCustomIngredient();
			if (customIngredient != null) {//Should basically always be the case
				Identifier name = customIngredient.getSerializer().getIdentifier();
				PECore.LOGGER.error(LogUtils.FATAL_MARKER, "Error mapping recipe {}. Ingredient of type: {} crashed when getting the matching stacks. "
														   + "Please report this to the ingredient's creator ({}).", recipeID, name, name.getNamespace(), e);
			} else {
				PECore.LOGGER.error(LogUtils.FATAL_MARKER, "Error mapping recipe {}. Crashed when getting the matching stacks.", recipeID, e);
			}
			return List.of();
		}
	}

	/**
	 * Returns true if it failed and is invalid
	 */
	private boolean addIngredient(Object2IntMap<NormalizedSimpleStack> ingredientMap, ItemStack stack, Identifier recipeID) {
		stack = stack.copy();
		Item item = stack.getItem();
		boolean hasContainerItem = false;
		try {
			//Note: We include the hasContainerItem check in the try catch, as if a mod is handling tags incorrectly
			// there is a chance their hasContainerItem is checking something about tags, and
			ItemStackTemplate container = item.getCraftingRemainder();
			hasContainerItem = container != null;
			if (hasContainerItem) {
				//If this item has a container for the stack, we remove the cost of the container itself
				ingredientMap.mergeInt(NSSItem.createItem(container.create()), -1, Constants.INT_SUM);
			}
		} catch (Exception e) {
			Identifier itemName = BuiltInRegistries.ITEM.getKey(item);
			if (hasContainerItem) {
				PECore.LOGGER.error(LogUtils.FATAL_MARKER, "Error mapping recipe {}. Item: {} reported that it has a container item, but errors when trying to get "
														   + "the container item based on the stack in the recipe. Please report this to {}.", recipeID, itemName,
						itemName.getNamespace(), e);
			} else {
				PECore.LOGGER.error(LogUtils.FATAL_MARKER, "Error mapping recipe {}. Item: {} crashed when checking if the stack in the recipe has a container item. "
														   + "Please report this to {}.", recipeID, itemName, itemName.getNamespace(), e);
			}
			//If something failed because the recipe errored, return that we did handle it so that we don't try to handle it later
			// as there is a 99% chance it will just fail again anyways
			return true;
		}
		ingredientMap.mergeInt(NSSItem.createItem(stack), 1, Constants.INT_SUM);
		return false;
	}

	@Nullable
	private Collection<Ingredient> getIngredientsChecked(RecipeHolder<?> recipeHolder) {
		try {
			return getIngredients(recipeHolder.value());
		} catch (Exception e) {
			Identifier recipeID = recipeHolder.id().identifier();
			PECore.LOGGER.error(LogUtils.FATAL_MARKER, "Error mapping recipe {}. Failed to get ingredients. Please report this to {}.", recipeID, recipeID.getNamespace(), e);
		}
		return null;
	}

	//Allow overwriting the ingredients list because Smithing recipes don't provide them via the placement info
	protected Collection<Ingredient> getIngredients(Recipe<?> recipe) {
		return recipe instanceof SmithingRecipe smithing ? Stream.of(Optional.of(smithing.baseIngredient()), smithing.additionIngredient(),
				smithing.templateIngredient()).flatMap(Optional::stream).toList() : recipe.placementInfo().ingredients();
	}
}
