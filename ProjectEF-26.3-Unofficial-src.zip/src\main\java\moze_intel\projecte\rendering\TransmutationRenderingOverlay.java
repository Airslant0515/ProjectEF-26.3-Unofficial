package moze_intel.projecte.rendering;

import com.mojang.blaze3d.vertex.PoseStack;
import com.mojang.blaze3d.vertex.VertexConsumer;
import it.unimi.dsi.fastutil.objects.Object2ReferenceMap;
import moze_intel.projecte.config.ProjectEConfig;
import moze_intel.projecte.gameObjs.items.PhilosophersStone;
import moze_intel.projecte.gameObjs.items.PhilosophersStone.PhilosophersStoneMode;
import moze_intel.projecte.gameObjs.registries.PEItems;
import net.fabricmc.fabric.api.client.rendering.v1.hud.HudElement;
import net.fabricmc.fabric.api.client.rendering.v1.level.LevelRenderContext;
import net.fabricmc.fabric.api.client.rendering.v1.level.LevelRenderEvents;
import net.minecraft.client.DeltaTracker;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.GuiGraphicsExtractor;
import net.minecraft.client.renderer.RenderPipelines;
import net.minecraft.client.renderer.SubmitNodeCollector;
import net.minecraft.client.renderer.block.FluidModel;
import net.minecraft.client.renderer.state.level.BlockOutlineRenderState;
import net.minecraft.client.color.block.BlockTintSource;
import net.minecraft.core.BlockPos;
import net.minecraft.util.ARGB;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.block.Block;
import net.minecraft.world.level.block.LiquidBlock;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.level.material.FluidState;
import net.minecraft.world.phys.BlockHitResult;
import net.minecraft.world.phys.HitResult;
import net.minecraft.world.phys.Vec3;
import net.minecraft.world.phys.shapes.CollisionContext;
import net.minecraft.world.phys.shapes.VoxelShape;
import org.jetbrains.annotations.NotNull;
import org.jetbrains.annotations.Nullable;

public class TransmutationRenderingOverlay implements HudElement, LevelRenderEvents.BeforeBlockOutline {

	private final Minecraft mc = Minecraft.getInstance();
	@Nullable
	private Block transmutationResult;
	private long lastGameTime;

	/**
	 * Renders the little preview of what the philosopher's stone will transmute the targeted block into, hooked into the hud render callback.
	 */
	@Override
	public void extractRenderState(@NotNull GuiGraphicsExtractor graphics, @NotNull DeltaTracker delta) {
		if (!mc.gui.hud.isHidden() && transmutationResult != null) {
			if (transmutationResult instanceof LiquidBlock liquidBlock) {
				//Note: LiquidBlock's fluid field is protected, so we get the (source) fluid state from the block state instead
				BlockState fluidBlockState = liquidBlock.defaultBlockState();
				FluidState fluidState = fluidBlockState.getFluidState();
				FluidModel model = mc.getModelManager().getFluidStateModelSet().get(fluidState);
				BlockTintSource tintSource = model.tintSource();
				//Note: Vanilla tints fluids in world via the biome they are in, when rendering it in the hud we don't have a position to query
				// so we fall back to no tint if the source is unable to provide a color without a level
				int color = tintSource == null ? -1 : tintSource.color(fluidBlockState);
				graphics.blitSprite(RenderPipelines.GUI_TEXTURED, model.stillMaterial().sprite(), 1, 1, 16, 16, color);
			} else {
				//Just render it normally instead of with the given model as some block's don't render properly then as an item
				// for example glass panes
				graphics.item(new ItemStack(transmutationResult), 1, 1);
			}
			long gameTime = mc.level == null ? 0 : mc.level.getGameTime();
			if (lastGameTime != gameTime) {
				//If the game time changed, so we aren't actually still hovering a block set our
				// result to null. We do this after rendering it just in case there is a single
				// frame where this may actually be valid based on the order the events are fired
				transmutationResult = null;
				lastGameTime = gameTime;
			}
		}
	}

	/**
	 * Highlights the blocks the philosopher's stone would change and remembers the result for the hud preview, hooked into the block outline render event.
	 *
	 * @return always true so the vanilla outline still renders.
	 */
	@Override
	public boolean beforeBlockOutline(@NotNull LevelRenderContext context, @NotNull BlockOutlineRenderState outlineState) {
		if (!(mc.getCameraEntity() instanceof Player player)) {
			return true;
		}
		Level level = player.level();
		lastGameTime = level.getGameTime();
		ItemStack stack = player.getMainHandItem();
		if (stack.isEmpty()) {
			stack = player.getOffhandItem();
		}
		if (stack.isEmpty() || !stack.is(PEItems.PHILOSOPHERS_STONE.get())) {
			transmutationResult = null;
			return true;
		}
		boolean isSneaking = player.isSecondaryUseActive();
		PhilosophersStone philoStone = (PhilosophersStone) stack.getItem();
		//Note: We use the philo stone's ray trace instead of the outline's position as we want to make sure that we
		// can properly take fluid into account/ignore it when needed
		BlockHitResult rtr = philoStone.getHitBlock(level, player, isSneaking);
		if (rtr.getType() == HitResult.Type.BLOCK) {
			int charge = philoStone.getCharge(stack);
			PhilosophersStoneMode mode = philoStone.getMode(stack);
			Object2ReferenceMap<BlockPos, BlockState> changes = PhilosophersStone.getChanges(level, rtr.getBlockPos(), rtr.getDirection(), player.getDirection(),
					isSneaking, mode, charge);
			if (changes.isEmpty()) {
				transmutationResult = null;
			} else {
				transmutationResult = changes.values().iterator().next().getBlock();
				Vec3 viewPosition = context.levelState().cameraRenderState.pos;
				float alpha = ProjectEConfig.client.pulsatingOverlay.get() ? getPulseProportion() * 0.60F : 0.35F;
				//Shift by view position here so that we don't have floating point issues at large values
				SubmitNodeCollector collector = context.submitNodeCollector();
				PoseStack matrix = context.poseStack();
				CollisionContext selectionContext = CollisionContext.of(player);
				collector.submitCustomGeometry(matrix, PERenderType.TRANSMUTATION_OVERLAY, (pose, builder) -> {
					int color = ARGB.colorFromFloat(alpha, 1, 1, 1);
					for (BlockPos pos : changes.keySet()) {
						BlockState state = level.getBlockState(pos);
						if (!state.isAir()) {
							VoxelShape shape = state.getShape(level, pos, selectionContext);
							if (!shape.isEmpty()) {
								double x = pos.getX() - viewPosition.x;
								double y = pos.getY() - viewPosition.y;
								double z = pos.getZ() - viewPosition.z;
								shape.forAllBoxes((minX, minY, minZ, maxX, maxY, maxZ) -> renderBox(pose, builder,
										(float) (minX + x), (float) (minY + y), (float) (minZ + z),
										(float) (maxX + x), (float) (maxY + y), (float) (maxZ + z), color));
							}
						}
					}
				});
			}
		} else {
			transmutationResult = null;
		}
		return true;
	}

	/**
	 * Emits the six faces of the given box as quads.
	 */
	private static void renderBox(PoseStack.Pose pose, VertexConsumer builder, float minX, float minY, float minZ, float maxX, float maxY, float maxZ, int color) {
		//Bottom
		quad(pose, builder, color, minX, minY, minZ, maxX, minY, minZ, maxX, minY, maxZ, minX, minY, maxZ);
		//Top
		quad(pose, builder, color, minX, maxY, maxZ, maxX, maxY, maxZ, maxX, maxY, minZ, minX, maxY, minZ);
		//North
		quad(pose, builder, color, minX, minY, minZ, minX, maxY, minZ, maxX, maxY, minZ, maxX, minY, minZ);
		//South
		quad(pose, builder, color, minX, minY, maxZ, maxX, minY, maxZ, maxX, maxY, maxZ, minX, maxY, maxZ);
		//West
		quad(pose, builder, color, minX, minY, minZ, minX, minY, maxZ, minX, maxY, maxZ, minX, maxY, minZ);
		//East
		quad(pose, builder, color, maxX, minY, minZ, maxX, maxY, minZ, maxX, maxY, maxZ, maxX, minY, maxZ);
	}

	private static void quad(PoseStack.Pose pose, VertexConsumer builder, int color,
			float x1, float y1, float z1, float x2, float y2, float z2, float x3, float y3, float z3, float x4, float y4, float z4) {
		vertex(pose, builder, x1, y1, z1, color);
		vertex(pose, builder, x2, y2, z2, color);
		vertex(pose, builder, x3, y3, z3, color);
		vertex(pose, builder, x4, y4, z4, color);
	}

	private static void vertex(PoseStack.Pose pose, VertexConsumer builder, float x, float y, float z, int color) {
		builder.addVertex(pose, x, y, z).setColor(color);
	}

	private float getPulseProportion() {
		return (float) (0.5F * Math.sin(System.currentTimeMillis() / 350.0) + 0.5F);
	}
}