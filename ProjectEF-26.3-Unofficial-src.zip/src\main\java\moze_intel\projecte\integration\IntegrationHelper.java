package moze_intel.projecte.integration;

import moze_intel.projecte.api.item_handlers.IItemHandler;
import moze_intel.projecte.integration.avaritia.AvaritiaIntegration;
import net.fabricmc.loader.api.FabricLoader;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.Item;
import org.jetbrains.annotations.Nullable;

public class IntegrationHelper {

	public static final String JEI_MODID = "jei";
	/**
	 * EMI hijacks JEI's plugin API, so the two recipe viewers should not both register the same recipes.
	 */
	public static final String EMI_MODID = "emi";

	/**
	 * Called during common mod init to hook up any loaded optional integrations.
	 * <p>
	 * Avaritia's additional recipes are supplied by an automatically enabled data pack.
	 */
	public static void init() {
		if (FabricLoader.getInstance().isModLoaded(AvaritiaIntegration.MODID)) {
			AvaritiaIntegration.registerRecipePack();
		}
	}

	/**
	 * Gets the accessory inventory of the given player, or null if no accessory provider is available.
	 * <p>
	 * Trinkets does not exist for this Minecraft version, so wearable projecte items are instead detected by scanning the
	 * player's hands and hotbar (see {@code PlayerHelper#checkHotbarCurios}), and this always returns {@code null}.
	 */
	@Nullable
	public static IItemHandler getCuriosInventory(Player player) {
		return null;
	}

	/**
	 * Registers the accessory capability for the given item, if an accessory provider is available.
	 * <p>
	 * No accessory provider is available for this Minecraft version, so this is a no-op.
	 */
	public static void registerCuriosCapability(Item item) {
	}
}
