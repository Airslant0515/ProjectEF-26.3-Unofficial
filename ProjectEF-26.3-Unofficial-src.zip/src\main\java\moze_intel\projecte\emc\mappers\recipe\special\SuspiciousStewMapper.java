package moze_intel.projecte.emc.mappers.recipe.special;

import moze_intel.projecte.api.mapper.recipe.RecipeTypeMapper;
import moze_intel.projecte.config.PEConfigTranslations;
import moze_intel.projecte.emc.mappers.recipe.BaseRecipeTypeMapper;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.Items;
import net.minecraft.world.item.crafting.CraftingRecipe;
import net.minecraft.world.item.crafting.Recipe;
import net.minecraft.world.item.crafting.RecipeType;

@RecipeTypeMapper
public class SuspiciousStewMapper extends BaseRecipeTypeMapper {

	@Override
	public boolean canHandle(RecipeType<?> recipeType) {
		return recipeType == RecipeType.CRAFTING;
	}

	@Override
	protected boolean canMap(Recipe<?> recipe, ItemStack output) {
		//Note: In 26.3 suspicious stew is no longer a special recipe, it is a set of normal shapeless recipes whose result carries
		// the suspicious stew effects component, so we allow the base mapper to handle them instead of skipping them
		return recipe instanceof CraftingRecipe && !recipe.isSpecial() && output.is(Items.SUSPICIOUS_STEW);
	}

	@Override
	public String getName() {
		return PEConfigTranslations.MAPPING_CRAFTING_MAPPER_SUSPICIOUS_STEW.title();
	}

	@Override
	public String getTranslationKey() {
		return PEConfigTranslations.MAPPING_CRAFTING_MAPPER_SUSPICIOUS_STEW.getTranslationKey();
	}

	@Override
	public String getDescription() {
		return PEConfigTranslations.MAPPING_CRAFTING_MAPPER_SUSPICIOUS_STEW.tooltip();
	}
}
