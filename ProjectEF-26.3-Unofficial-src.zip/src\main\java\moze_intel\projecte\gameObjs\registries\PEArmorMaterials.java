package moze_intel.projecte.gameObjs.registries;

import java.util.EnumMap;
import java.util.Map;
import moze_intel.projecte.PECore;
import net.minecraft.core.registries.Registries;
import net.minecraft.resources.ResourceKey;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.tags.ItemTags;
import net.minecraft.util.Util;
import net.minecraft.world.item.equipment.ArmorMaterial;
import net.minecraft.world.item.equipment.ArmorType;
import net.minecraft.world.item.equipment.EquipmentAsset;
import net.minecraft.world.item.equipment.EquipmentAssets;

/**
 * Armor materials used by ProjectE armor. Since 1.21.2 armor materials are plain records instead of registry entries, and the visual armor texture is selected by
 * an {@link EquipmentAsset} key instead of a layer list.
 */
public class PEArmorMaterials {

	private PEArmorMaterials() {
	}

	private static final Map<ArmorType, Integer> DIAMOND_RESISTANCES = Util.make(new EnumMap<>(ArmorType.class), map -> {
		map.put(ArmorType.BOOTS, 3);
		map.put(ArmorType.LEGGINGS, 6);
		map.put(ArmorType.CHESTPLATE, 8);
		map.put(ArmorType.HELMET, 3);
		map.put(ArmorType.BODY, 11);
	});

	public static final ResourceKey<EquipmentAsset> DARK_MATTER_ASSET = asset("dark_matter");
	public static final ResourceKey<EquipmentAsset> RED_MATTER_ASSET = asset("red_matter");
	public static final ResourceKey<EquipmentAsset> GEM_ARMOR_ASSET = asset("gem_armor");

	public static final ArmorMaterial DARK_MATTER = material(0.1F, DARK_MATTER_ASSET);
	public static final ArmorMaterial RED_MATTER = material(0.2F, RED_MATTER_ASSET);
	public static final ArmorMaterial GEM_ARMOR = material(0.25F, GEM_ARMOR_ASSET);

	private static ArmorMaterial material(float knockbackResistance, ResourceKey<EquipmentAsset> asset) {
		return new ArmorMaterial(0, DIAMOND_RESISTANCES, 0, SoundEvents.ARMOR_EQUIP_NETHERITE, 2.0F, knockbackResistance,
				//The repair ingredient has to be a real tag: humanoidArmor calls Item.Properties#repairable(TagKey) which dereferences it eagerly.
				ItemTags.NETHERITE_TOOL_MATERIALS, asset);
	}

	private static ResourceKey<EquipmentAsset> asset(String name) {
		return ResourceKey.create(EquipmentAssets.ROOT_ID, PECore.rl(name));
	}

	/**
	 * Kept for backwards compatibility with code that used to resolve materials through a deferred holder.
	 */
	public static void init() {
		//Intentionally empty: materials are static data in the current version.
	}
}
