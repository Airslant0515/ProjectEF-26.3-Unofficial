package moze_intel.projecte.emc.mappers;

import java.util.ArrayList;
import java.util.List;
import moze_intel.projecte.PECore;
import moze_intel.projecte.api.mapper.EMCMapper;
import moze_intel.projecte.api.mapper.IEMCMapper;
import moze_intel.projecte.api.mapper.collector.IMappingCollector;
import moze_intel.projecte.api.nss.NSSFluid;
import moze_intel.projecte.api.nss.NSSItem;
import moze_intel.projecte.api.nss.NormalizedSimpleStack;
import moze_intel.projecte.config.PEConfigTranslations;
import moze_intel.projecte.emc.mappers.recipe.BaseRecipeTypeMapper;
import moze_intel.projecte.utils.EMCHelper;
import net.minecraft.core.Holder;
import net.minecraft.core.RegistryAccess;
import net.minecraft.core.component.DataComponents;
import net.minecraft.core.registries.BuiltInRegistries;
import net.minecraft.server.packs.resources.ResourceManager;
import net.minecraft.tags.FluidTags;
import net.minecraft.util.context.ContextMap;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.Items;
import net.minecraft.world.item.alchemy.Potion;
import net.minecraft.world.item.alchemy.PotionContents;
import net.minecraft.world.item.alchemy.Potions;
import net.minecraft.world.item.crafting.BrewingRecipe;
import net.minecraft.world.item.crafting.PotionIngredient;
import net.minecraft.world.item.crafting.RecipeHolder;
import net.minecraft.world.item.crafting.RecipeManager;
import org.jetbrains.annotations.Nullable;

@EMCMapper
public class BrewingMapper implements IEMCMapper<NormalizedSimpleStack, Long> {

	@Override
	public void addMappings(IMappingCollector<NormalizedSimpleStack, Long> mapper, RecipeManager recipeManager, RegistryAccess registryAccess,
			ResourceManager resourceManager) {
		//Add conversion for empty bottle + water to water bottle
		//Note: NSS fluid amounts are in millibuckets (1 bucket = 1000 mB), so a water bottle holds 1000 / 3 mB of water
		mapper.addConversion(1, NSSItem.createItem(PotionContents.createItemStack(Items.POTION, Potions.WATER)), EMCHelper.intMapOf(
				NSSItem.createItem(Items.GLASS_BOTTLE), 1,
				NSSFluid.createTag(FluidTags.WATER), 1_000 / 3
		));

		int recipeCount = 0;
		ContextMap context = BaseRecipeTypeMapper.displayContext(registryAccess);
		//Note: Brewing is data driven in 26.3, and the recipes are the only source of truth for what can be brewed
		for (RecipeHolder<?> recipeHolder : recipeManager.getRecipes()) {
			if (recipeHolder.value() instanceof BrewingRecipe brewingRecipe) {
				List<ItemStack> validInputs = getMatchingStacks(brewingRecipe.getInput(), context);
				List<ItemStack> validReagents = getMatchingStacks(brewingRecipe.getReagent(), context);
				if (validInputs != null && validReagents != null) {
					ItemStack output = brewingRecipe.getOutput().create();
					NormalizedSimpleStack nssOut = NSSItem.createItem(output);
					for (ItemStack validInput : validInputs) {
						NormalizedSimpleStack nssInput = NSSItem.createItem(validInput);
						for (ItemStack validReagent : validReagents) {
							//Add the conversion, 3 input + reagent = 3 y output as the output technically could be stacked
							mapper.addConversion(3 * output.getCount(), nssOut, EMCHelper.intMapOf(
									nssInput, 3,
									NSSItem.createItem(validReagent), validReagent.getCount()
							));
							recipeCount++;
						}
					}
				}
			}
		}
		PECore.debugLog("{} Statistics:", getName());
		PECore.debugLog("Found {} Brewing Recipes", recipeCount);
	}

	@Override
	public String getName() {
		return PEConfigTranslations.MAPPING_BREWING_MAPPER.title();
	}

	@Override
	public String getTranslationKey() {
		return PEConfigTranslations.MAPPING_BREWING_MAPPER.getTranslationKey();
	}

	@Override
	public String getDescription() {
		return PEConfigTranslations.MAPPING_BREWING_MAPPER.tooltip();
	}

	@Nullable
	private static List<ItemStack> getMatchingStacks(PotionIngredient ingredient, ContextMap context) {
		List<ItemStack> stacks;
		try {
			stacks = BaseRecipeTypeMapper.getStacks(ingredient.ingredient(), context);
		} catch (Exception e) {
			return null;
		}
		if (ingredient.potions().isEmpty()) {
			//Not a potion specific part of the recipe, so all the stacks that match the ingredient are valid
			return stacks;
		}
		//The ingredient is restricted to specific potions, so we need to create the stacks for each of the valid potions
		List<ItemStack> potionStacks = new ArrayList<>();
		for (Holder<Potion> potion : BuiltInRegistries.POTION.listElements().toList()) {
			PotionContents contents = new PotionContents(potion);
			if (ingredient.potions().get().matches(contents)) {
				for (ItemStack stack : stacks) {
					ItemStack potionStack = stack.copy();
					potionStack.set(DataComponents.POTION_CONTENTS, contents);
					potionStacks.add(potionStack);
				}
			}
		}
		return potionStacks;
	}
}
