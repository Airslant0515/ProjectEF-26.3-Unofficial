package moze_intel.projecte.gameObjs;

import net.minecraft.world.item.ToolMaterial;

/**
 * Matter tier data used by ProjectE tools. In 1.26.x vanilla removed {@code Tier}/{@code DiggerItem} in favour of {@link ToolMaterial} plus item properties.
 */
public interface IMatterType {

	/**
	 * The vanilla tool material backing this matter type.
	 */
	ToolMaterial getToolMaterial();

	float getChargeModifier();

	int getMatterTier();
}
