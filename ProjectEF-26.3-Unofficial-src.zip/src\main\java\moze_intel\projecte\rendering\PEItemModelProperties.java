package moze_intel.projecte.rendering;

import com.mojang.serialization.MapCodec;
import moze_intel.projecte.PECore;
import moze_intel.projecte.gameObjs.items.rings.Arcana.ArcanaMode;
import moze_intel.projecte.gameObjs.items.rings.SWRG.SWRGMode;
import moze_intel.projecte.gameObjs.registries.PEDataComponentTypes;
import moze_intel.projecte.gameObjs.registries.PEItems;
import net.minecraft.client.multiplayer.ClientLevel;
import net.minecraft.client.renderer.item.properties.conditional.ConditionalItemModelProperties;
import net.minecraft.client.renderer.item.properties.conditional.ConditionalItemModelProperty;
import net.minecraft.client.renderer.item.properties.numeric.RangeSelectItemModelProperties;
import net.minecraft.client.renderer.item.properties.numeric.RangeSelectItemModelProperty;
import net.minecraft.world.entity.ItemOwner;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.item.ItemDisplayContext;
import net.minecraft.world.item.ItemStack;
import org.jetbrains.annotations.NotNull;
import org.jetbrains.annotations.Nullable;

/**
 * Custom item model properties used by the 1.21.4+ item model definitions in {@code assets/projecte/items}.
 * <p>
 * 26.3 replaced the old {@code ItemProperties.register} predicate system with item model definitions, so the "active" and "mode" states that used to be
 * model overrides are now dispatched through these properties.
 */
public final class PEItemModelProperties {

	public static final net.minecraft.resources.Identifier ACTIVE = PECore.rl("active");
	public static final net.minecraft.resources.Identifier MODE = PECore.rl("mode");

	private PEItemModelProperties() {
	}

	/**
	 * Registers our properties. Must run during client initialization so the item model definitions can resolve them on the first model bake.
	 */
	public static void init() {
		ConditionalItemModelProperties.ID_MAPPER.put(ACTIVE, Active.MAP_CODEC);
		RangeSelectItemModelProperties.ID_MAPPER.put(MODE, Mode.MAP_CODEC);
	}

	/**
	 * Whether the item is currently activated (rings that toggle).
	 */
	public record Active() implements ConditionalItemModelProperty {

		public static final MapCodec<Active> MAP_CODEC = MapCodec.unit(new Active());

		@Override
		public boolean get(@NotNull ItemStack stack, @Nullable ClientLevel level, @Nullable LivingEntity owner, int seed,
				@NotNull ItemDisplayContext displayContext) {
			return stack.getOrDefault(PEDataComponentTypes.ACTIVE.get(), false);
		}

		@NotNull
		@Override
		public MapCodec<Active> type() {
			return MAP_CODEC;
		}
	}

	/**
	 * The ordinal of the item's mode, used to pick which variant of the item model is drawn.
	 */
	public record Mode() implements RangeSelectItemModelProperty {

		public static final MapCodec<Mode> MAP_CODEC = MapCodec.unit(new Mode());

		@Override
		public float get(@NotNull ItemStack stack, @Nullable ClientLevel level, @Nullable ItemOwner owner, int seed) {
			if (stack.is(PEItems.ARCANA_RING.get())) {
				ArcanaMode mode = stack.getOrDefault(PEDataComponentTypes.ARCANA_MODE.get(), PEItems.ARCANA_RING.get().getDefaultMode());
				return mode.ordinal();
			} else if (stack.is(PEItems.SWIFTWOLF_RENDING_GALE.get())) {
				SWRGMode mode = stack.getOrDefault(PEDataComponentTypes.SWRG_MODE.get(), SWRGMode.OFF);
				return mode.ordinal();
			}
			return 0;
		}

		@NotNull
		@Override
		public MapCodec<Mode> type() {
			return MAP_CODEC;
		}
	}
}
