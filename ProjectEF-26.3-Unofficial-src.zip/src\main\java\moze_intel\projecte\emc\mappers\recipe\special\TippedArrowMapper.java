package moze_intel.projecte.emc.mappers.recipe.special;

import java.util.List;
import java.util.Optional;
import moze_intel.projecte.PECore;
import moze_intel.projecte.api.mapper.collector.IMappingCollector;
import moze_intel.projecte.api.mapper.recipe.INSSFakeGroupManager;
import moze_intel.projecte.api.mapper.recipe.RecipeTypeMapper;
import moze_intel.projecte.api.nss.NSSItem;
import moze_intel.projecte.api.nss.NormalizedSimpleStack;
import moze_intel.projecte.config.PEConfigTranslations;
import moze_intel.projecte.emc.mappers.recipe.BaseRecipeTypeMapper;
import moze_intel.projecte.utils.EMCHelper;
import net.minecraft.core.Holder;
import net.minecraft.core.RegistryAccess;
import net.minecraft.core.component.DataComponentPatch;
import net.minecraft.core.component.DataComponents;
import net.minecraft.core.registries.BuiltInRegistries;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.alchemy.Potion;
import net.minecraft.world.item.alchemy.PotionContents;
import net.minecraft.world.item.crafting.ImbueRecipe;
import net.minecraft.world.item.crafting.Ingredient;

@RecipeTypeMapper
public class TippedArrowMapper extends SpecialRecipeMapper<ImbueRecipe> {

	@Override
	protected Class<ImbueRecipe> getRecipeClass() {
		return ImbueRecipe.class;
	}

	@Override
	protected boolean handleRecipe(IMappingCollector<NormalizedSimpleStack, Long> mapper, ImbueRecipe recipe, RegistryAccess registryAccess,
			INSSFakeGroupManager fakeGroupManager) {
		//Note: In 26.3 tipped arrows are an imbue recipe (lingering potion in the center, arrows around it) instead of a dedicated TippedArrowRecipe
		List<Ingredient> ingredients = recipe.placementInfo().ingredients();
		ItemStack output = BaseRecipeTypeMapper.getResult(recipe, registryAccess);
		if (ingredients.size() != 9 || output.isEmpty()) {
			return false;
		}
		Optional<Holder<Item>> material = ingredients.getFirst().getSingleItem();
		Optional<Holder<Item>> source = ingredients.get(4).getSingleItem();
		if (material.isEmpty() || source.isEmpty()) {
			return false;
		}
		NSSItem nssMaterial = NSSItem.createItem(material.get());
		int materialCount = output.getCount();
		List<Holder.Reference<Potion>> potions = BuiltInRegistries.POTION.listElements().toList();
		for (Holder<Potion> potionType : potions) {
			PotionContents potionContents = new PotionContents(potionType);
			mapper.addConversion(materialCount, createItem(output.typeHolder(), potionContents), EMCHelper.intMapOf(
					nssMaterial, materialCount,
					createItem(source.get(), potionContents), 1
			));
		}
		PECore.debugLog("{} Statistics:", getName());
		PECore.debugLog("Found {} Tipped Arrow Recipes", potions.size());
		return true;
	}

	private NSSItem createItem(Holder<Item> item, PotionContents contents) {
		return NSSItem.createItem(item, DataComponentPatch.builder().set(DataComponents.POTION_CONTENTS, contents).build());
	}

	@Override
	public String getName() {
		return PEConfigTranslations.MAPPING_CRAFTING_MAPPER_TIPPED_ARROW.title();
	}

	@Override
	public String getTranslationKey() {
		return PEConfigTranslations.MAPPING_CRAFTING_MAPPER_TIPPED_ARROW.getTranslationKey();
	}

	@Override
	public String getDescription() {
		return PEConfigTranslations.MAPPING_CRAFTING_MAPPER_TIPPED_ARROW.tooltip();
	}
}
