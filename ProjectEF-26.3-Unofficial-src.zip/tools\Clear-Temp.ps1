﻿#Requires -Version 5.1
<#
.SYNOPSIS
    Remove temporary export/unpack directories created by tools\Extract-EmcAndRecipes.ps1.

.DESCRIPTION
    This script can only delete directories directly under  <repo>\tmp\  whose name starts with
    "export-" or "_unpacked-". It refuses to touch anything else: not the repository root, not
    data\, not the game instance, and it never terminates any process.

.PARAMETER OlderThanDays
    Only delete directories whose last write time is older than this many days. Default 0 (all).

.PARAMETER WhatIfOnly
    List what would be deleted without deleting anything.

.EXAMPLE
    powershell -ExecutionPolicy Bypass -File .\tools\Clear-Temp.ps1

.EXAMPLE
    powershell -ExecutionPolicy Bypass -File .\tools\Clear-Temp.ps1 -WhatIfOnly
#>
[CmdletBinding(SupportsShouldProcess = $true)]
param(
    [int]$OlderThanDays = 0,
    [switch]$WhatIfOnly
)

Set-StrictMode -Version Latest
$ErrorActionPreference = 'Stop'

$PSScriptRootFull = Split-Path -Parent $PSScriptRoot
$repoRoot = $PSScriptRootFull
$tmpRoot = Join-Path $repoRoot 'tmp'

if (-not (Test-Path -LiteralPath $tmpRoot)) {
    Write-Host "[info] tmp\ 不存在，无需清理。"
    return
}

$tmpFull = [System.IO.Path]::GetFullPath($tmpRoot).TrimEnd('\')
$cutoff = (Get-Date).AddDays(-1 * [Math]::Abs($OlderThanDays))

$targets = Get-ChildItem -LiteralPath $tmpFull -Directory -ErrorAction SilentlyContinue |
    Where-Object { $_.Name -like 'export-*' -or $_.Name -like '_unpacked-*' } |
    Where-Object { $_.LastWriteTime -le $cutoff }

if ($targets.Count -eq 0) {
    Write-Host "[info] tmp\ 下没有需要清理的导出目录。"
    return
}

foreach ($dir in $targets) {
    # Double check: it must be a direct child of tmp\ and match the naming rule we created.
    $full = [System.IO.Path]::GetFullPath($dir.FullName)
    $parent = [System.IO.Path]::GetDirectoryName($full)
    $isDirectChild = ($parent.TrimEnd('\') -eq $tmpFull)
    $nameOk = ($dir.Name -like 'export-*' -or $dir.Name -like '_unpacked-*')
    if (-not ($isDirectChild -and $nameOk)) {
        Write-Warning "跳过（不符合安全规则）: $full"
        continue
    }
    if ($WhatIfOnly) {
        Write-Host "[whatif] 将删除: $($dir.Name)"
        continue
    }
    if ($PSCmdlet.ShouldProcess($dir.Name, 'Remove-Item -Recurse')) {
        Remove-Item -LiteralPath $full -Recurse -Force
        Write-Host "[ok] 已删除: $($dir.Name)"
    }
}

Write-Host "[done] 清理结束（范围仅限 $tmpFull）。"
