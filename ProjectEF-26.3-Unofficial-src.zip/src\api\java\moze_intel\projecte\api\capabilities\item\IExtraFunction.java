package moze_intel.projecte.api.capabilities.item;

import net.minecraft.world.InteractionHand;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.ItemStack;
import org.jetbrains.annotations.NotNull;
import org.jetbrains.annotations.Nullable;

/**
 * This interface specifies items that perform a specific function when the Extra Function key is activated (default C)
 * <p>
 * This is exposed through the Capability system.
 * <p>
 * Acquire an instance of this by querying {@link moze_intel.projecte.api.capabilities.PECapabilities#EXTRA_FUNCTION_ITEM_CAPABILITY} for a given stack.
 */
public interface IExtraFunction {

	/**
	 * Called serverside when the server receives an Extra Function key packet
	 *
	 * @param player The player performing this function
	 * @param stack  The ItemStack performing this function
	 * @param hand   The hand this stack was in, or null if the call was not from the player's hands
	 *
	 * @return Whether the operation succeeded
	 */
	boolean doExtraFunction(@NotNull Player player, @NotNull ItemStack stack, @Nullable InteractionHand hand);
}