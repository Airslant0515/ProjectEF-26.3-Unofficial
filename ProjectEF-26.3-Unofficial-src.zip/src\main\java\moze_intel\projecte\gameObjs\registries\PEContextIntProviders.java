package moze_intel.projecte.gameObjs.registries;

import moze_intel.projecte.PECore;
import net.minecraft.core.registries.Registries;
import net.minecraft.resources.ResourceKey;
import net.minecraft.world.level.storage.loot.providers.number.ints.ContextIntProvider;

/**
 * Keys for the data driven cooking (furnace burn) times of ProjectE's fuels. The matching values live in
 * {@code data/projecte/context_int_provider/cooking/*.json}.
 */
public class PEContextIntProviders {

	public static final ResourceKey<ContextIntProvider> COOKING_TIME_ALCHEMICAL_COAL = createKey("cooking/time_alchemical_coal");
	public static final ResourceKey<ContextIntProvider> COOKING_TIME_ALCHEMICAL_COAL_BLOCK = createKey("cooking/time_alchemical_coal_block");
	public static final ResourceKey<ContextIntProvider> COOKING_TIME_MOBIUS_FUEL = createKey("cooking/time_mobius_fuel");
	public static final ResourceKey<ContextIntProvider> COOKING_TIME_MOBIUS_FUEL_BLOCK = createKey("cooking/time_mobius_fuel_block");
	public static final ResourceKey<ContextIntProvider> COOKING_TIME_AETERNALIS_FUEL = createKey("cooking/time_aeternalis_fuel");
	public static final ResourceKey<ContextIntProvider> COOKING_TIME_AETERNALIS_FUEL_BLOCK = createKey("cooking/time_aeternalis_fuel_block");

	private static ResourceKey<ContextIntProvider> createKey(String location) {
		return ResourceKey.create(Registries.CONTEXT_INT_PROVIDER, PECore.rl(location));
	}
}
