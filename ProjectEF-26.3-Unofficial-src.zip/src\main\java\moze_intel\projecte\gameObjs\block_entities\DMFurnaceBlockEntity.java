package moze_intel.projecte.gameObjs.block_entities;

import com.mojang.serialization.Codec;
import it.unimi.dsi.fastutil.objects.Object2IntMap;
import it.unimi.dsi.fastutil.objects.Object2IntMaps;
import it.unimi.dsi.fastutil.objects.Object2IntOpenHashMap;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Optional;
import moze_intel.projecte.api.capabilities.PECapabilities;
import moze_intel.projecte.api.capabilities.item.IItemEmcHolder;
import moze_intel.projecte.gameObjs.blocks.MatterFurnace;
import moze_intel.projecte.gameObjs.container.DMFurnaceContainer;
import moze_intel.projecte.gameObjs.container.slots.SlotPredicates;
import moze_intel.projecte.gameObjs.registration.impl.BlockEntityTypeRegistryObject;
import moze_intel.projecte.gameObjs.registries.PEBlockEntityTypes;
import moze_intel.projecte.utils.WorldHelper;
import moze_intel.projecte.utils.text.PELang;
import net.minecraft.SharedConstants;
import net.minecraft.core.BlockPos;
import net.minecraft.core.Direction;
import net.minecraft.core.component.DataComponents;
import net.minecraft.network.chat.Component;
import net.minecraft.resources.ResourceKey;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.util.Mth;
import net.minecraft.util.RandomSource;
import net.minecraft.world.MenuProvider;
import net.minecraft.world.entity.ExperienceOrb;
import net.minecraft.world.entity.player.Inventory;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.inventory.AbstractContainerMenu;
import net.minecraft.world.inventory.RecipeCraftingHolder;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.ItemStackTemplate;
import net.minecraft.world.item.Items;
import net.minecraft.world.item.component.CookingFuel;
import net.minecraft.world.item.crafting.Recipe;
import net.minecraft.world.item.crafting.RecipeHolder;
import net.minecraft.world.item.crafting.RecipeManager;
import net.minecraft.world.item.crafting.RecipePropertySet;
import net.minecraft.world.item.crafting.RecipeType;
import net.minecraft.world.item.crafting.SingleRecipeInput;
import net.minecraft.world.item.crafting.SmeltingRecipe;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.block.entity.AbstractFurnaceBlockEntity;
import net.minecraft.world.level.block.entity.Hopper;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.level.storage.ValueInput;
import net.minecraft.world.level.storage.ValueOutput;
import net.minecraft.world.level.storage.loot.LootContext;
import net.minecraft.world.level.storage.loot.LootParams;
import net.minecraft.world.level.storage.loot.parameters.LootContextParamSets;
import net.minecraft.world.level.storage.loot.parameters.LootContextParams;
import net.minecraft.world.level.storage.loot.providers.number.ints.ResolvableInt;
import net.minecraft.world.phys.Vec3;
import net.fabricmc.fabric.api.lookup.v1.block.BlockApiCache;
import net.fabricmc.fabric.api.tag.convention.v2.ConventionalItemTags;
import net.fabricmc.fabric.api.transfer.v1.item.ItemStorage;
import net.fabricmc.fabric.api.transfer.v1.item.ItemVariant;
import net.fabricmc.fabric.api.transfer.v1.storage.Storage;
import java.util.function.BiFunction;
import moze_intel.projecte.api.item_handlers.IItemHandler;
import moze_intel.projecte.api.item_handlers.IItemHandlerModifiable;
import moze_intel.projecte.api.item_handlers.ItemHandlerHelper;
import moze_intel.projecte.api.item_handlers.CombinedInvWrapper;
import moze_intel.projecte.api.item_handlers.StorageItemHandler;
import org.jetbrains.annotations.NotNull;
import org.jetbrains.annotations.Nullable;
import org.jetbrains.annotations.Range;

public class DMFurnaceBlockEntity extends EmcBlockEntity implements MenuProvider, RecipeCraftingHolder, PEWorldlyContainer {

	public static final BiFunction<DMFurnaceBlockEntity, @Nullable Direction, IItemHandler> INVENTORY_PROVIDER = (furnace, side) -> {
		if (side == null) {
			return furnace.joined;
		} else if (side == Direction.UP) {
			return furnace.automationInput;
		} else if (side == Direction.DOWN) {
			return furnace.automationOutput;
		}
		return furnace.automationSides;
	};
	private static final long EMC_CONSUMPTION = 2;
	private static final Codec<Map<ResourceKey<Recipe<?>>, Integer>> RECIPES_USED_CODEC = Codec.unboundedMap(Recipe.KEY_CODEC, Codec.INT);

	private final CompactableStackHandler inputInventory = new CompactableStackHandler(getInvSize()) {
		private ItemStack oldInput = ItemStack.EMPTY;

		@Override
		protected void onLoad() {
			oldInput = getStackInSlot(0).copy();
		}

		@Override
		protected void onContentsChanged(int slot) {
			super.onContentsChanged(slot);
			if (slot == 0) {
				ItemStack input = getStackInSlot(0);
				if (!ItemStack.isSameItemSameComponents(oldInput, input)) {
					//Reset the cooking progress
					RecipeResult recipeResult = getSmeltingRecipe(input);
					cookingTotalTime = getTotalCookTime(recipeResult);
					cookingProgress = 0;
					oldInput = input.copy();
				}
			}
		}
	};
	private final CompactableStackHandler outputInventory = new CompactableStackHandler(getInvSize());
	private final StackHandler fuelInv = new StackHandler(1);

	private final IItemHandler joined;
	private final IItemHandlerModifiable automationInput;
	private final IItemHandlerModifiable automationOutput;
	private final IItemHandler automationSides;

	protected final int ticksBeforeSmelt;
	private final int efficiencyBonus;
	private final Object2IntOpenHashMap<ResourceKey<Recipe<?>>> recipesUsed = new Object2IntOpenHashMap<>();
	private final RecipeManager.CachedCheck<SingleRecipeInput, SmeltingRecipe> quickCheck;

	@Nullable
	private BlockApiCache<Storage<ItemVariant>, Direction> pullTarget;
	@Nullable
	private BlockApiCache<Storage<ItemVariant>, Direction> pushTarget;

	public int litTime;
	public int litDuration;
	public int cookingProgress;
	public int cookingTotalTime;

	public DMFurnaceBlockEntity(BlockPos pos, BlockState state) {
		this(PEBlockEntityTypes.DARK_MATTER_FURNACE, pos, state, SharedConstants.TICKS_PER_SECOND / 2, 3);
	}

	protected DMFurnaceBlockEntity(BlockEntityTypeRegistryObject<? extends DMFurnaceBlockEntity> type, BlockPos pos, BlockState state, int ticksBeforeSmelt, int efficiencyBonus) {
		super(type, pos, state, 64);
		this.ticksBeforeSmelt = ticksBeforeSmelt;
		this.efficiencyBonus = efficiencyBonus;
		this.quickCheck = RecipeManager.createCheck(RecipeType.SMELTING);

		this.automationInput = new WrappedItemHandler(inputInventory, WrappedItemHandler.WriteMode.IN) {
			@NotNull
			@Override
			public ItemStack insertItem(int slot, @NotNull ItemStack stack, boolean simulate) {
				return hasSmeltingResult(stack) ? super.insertItem(slot, stack, simulate) : stack;
			}
		};
		this.automationOutput = new WrappedItemHandler(outputInventory, WrappedItemHandler.WriteMode.OUT);
		IItemHandlerModifiable automationFuel = new WrappedItemHandler(fuelInv, WrappedItemHandler.WriteMode.IN) {
			@NotNull
			@Override
			public ItemStack insertItem(int slot, @NotNull ItemStack stack, boolean simulate) {
				return SlotPredicates.FURNACE_FUEL.test(stack) ? super.insertItem(slot, stack, simulate) : stack;
			}
		};
		this.automationSides = new CombinedInvWrapper(automationFuel, automationOutput);
		this.joined = new CombinedInvWrapper(automationInput, automationFuel, automationOutput);
	}

	@Override
	public void setLevel(@NotNull Level level) {
		super.setLevel(level);
		if (level instanceof ServerLevel serverLevel) {
			pullTarget = BlockApiCache.create(ItemStorage.SIDED, serverLevel, worldPosition.above());
			pushTarget = BlockApiCache.create(ItemStorage.SIDED, serverLevel, worldPosition.below());
		}
	}

	@Override
	protected boolean canProvideEmc() {
		return false;
	}

	@Override
	@Range(from = 0, to = Long.MAX_VALUE)
	protected long getEmcInsertLimit() {
		return EMC_CONSUMPTION;
	}

	protected int getInvSize() {
		return 9;
	}

	protected float getOreDoubleChance() {
		return 0.5F;
	}

	protected float getDoubleChance(ItemStack input) {
		if (input.is(ConventionalItemTags.ORES)) {
			return getOreDoubleChance();
		} else if (input.is(ConventionalItemTags.RAW_MATERIALS)) {
			//Base rate for raw ore doubling chance is: 1 -> 1.333 which means we multiply our ore double chance by 2/3
			return getOreDoubleChance() * 2 / 3;
		}
		return 0;
	}

	public float getBurnProgress() {
		if (cookingTotalTime == 0) {
			return 0;
		}
		//Adjust by one so that it can look like it is actually reaching the end of the bar
		int progress = isLit() && canSmelt(getSmeltingRecipe(getItemToSmelt())) ? cookingProgress + 1 : cookingProgress;
		return Mth.clamp(progress / (float) cookingTotalTime, 0, 1);
	}

	@NotNull
	@Override
	public AbstractContainerMenu createMenu(int windowId, @NotNull Inventory playerInv, @NotNull Player playerIn) {
		return new DMFurnaceContainer(windowId, playerInv, this);
	}

	@NotNull
	@Override
	public Component getDisplayName() {
		return PELang.GUI_DARK_MATTER_FURNACE.translate();
	}

	public IItemHandler getFuel() {
		return fuelInv;
	}

	private ItemStack getItemToSmelt() {
		return inputInventory.getStackInSlot(0);
	}

	private ItemStack getFuelItem() {
		return fuelInv.getStackInSlot(0);
	}

	public IItemHandler getInput() {
		return inputInventory;
	}

	public IItemHandler getOutput() {
		return outputInventory;
	}

	public static void tickServer(Level level, BlockPos pos, BlockState state, DMFurnaceBlockEntity furnace) {
		boolean wasBurning = furnace.isLit();
		int lastLitTime = furnace.litTime;
		int lastCookingProgress = furnace.cookingProgress;
		if (furnace.isLit()) {
			--furnace.litTime;
		}
		furnace.inputInventory.compact();
		furnace.outputInventory.compact();
		furnace.pullFromInventories(level, pos);

		RecipeResult recipeResult = furnace.getSmeltingRecipe(level, furnace.getItemToSmelt());
		boolean canSmelt = furnace.canSmelt(recipeResult);
		ItemStack fuelItem = furnace.getFuelItem();
		if (canSmelt) {
			IItemEmcHolder emcHolder = PECapabilities.EMC_HOLDER_ITEM_CAPABILITY.find(fuelItem);
			if (emcHolder != null) {
				long simulatedExtraction = emcHolder.extractEmc(fuelItem, EMC_CONSUMPTION, EmcAction.SIMULATE);
				if (simulatedExtraction == EMC_CONSUMPTION) {
					furnace.forceInsertEmc(emcHolder.extractEmc(fuelItem, simulatedExtraction, EmcAction.EXECUTE), EmcAction.EXECUTE);
				}
				furnace.markDirty(level, pos, false);
			}
		}

		if (furnace.getStoredEmc() >= EMC_CONSUMPTION) {
			furnace.litTime = 1;
			furnace.forceExtractEmc(EMC_CONSUMPTION, EmcAction.EXECUTE);
		}

		if (canSmelt) {
			if (furnace.litTime == 0) {
				if (level instanceof ServerLevel serverLevel) {
					furnace.litDuration = furnace.litTime = furnace.getItemBurnTime(serverLevel, fuelItem);
				} else {
					furnace.litDuration = furnace.litTime = 0;
				}
				if (furnace.isLit() && !fuelItem.isEmpty()) {
					ItemStack copy = fuelItem.copy();
					fuelItem.shrink(1);
					furnace.fuelInv.onContentsChanged(0);
					if (fuelItem.isEmpty()) {
						ItemStackTemplate remainder = copy.getItem().getCraftingRemainder();
						furnace.fuelInv.setStackInSlot(0, remainder == null ? ItemStack.EMPTY : remainder.create());
					}
					furnace.markDirty(level, pos, false);
				}
			}
			if (furnace.isLit() && ++furnace.cookingProgress == furnace.cookingTotalTime) {
				furnace.cookingProgress = 0;
				furnace.cookingTotalTime = furnace.getTotalCookTime(recipeResult);
				furnace.smeltItem(level, recipeResult);
			}
		} else {
			furnace.cookingProgress = 0;
		}
		if (wasBurning != furnace.isLit()) {
			if (state.getBlock() instanceof MatterFurnace) {
				//Should always be true, but validate it just in case
				level.setBlockAndUpdate(pos, state.setValue(MatterFurnace.LIT, furnace.isLit()));
			}
			furnace.markDirty(level, pos, true);
		}
		furnace.pushToInventories(level, pos);
		if (lastLitTime != furnace.litTime || lastCookingProgress != furnace.cookingProgress) {
			furnace.markDirty(level, pos, false);
		}
		furnace.updateComparators(level, pos);
	}

	public boolean isLit() {
		return litTime > 0;
	}

	private static boolean isHopper(@NotNull Level level, @NotNull BlockPos position) {
		//We let hoppers go at their normal rate
		return WorldHelper.getBlockEntity(level, position) instanceof Hopper;
	}

	private void pullFromInventories(@NotNull Level level, @NotNull BlockPos pos) {
		if (pullTarget == null || isHopper(level, pos.above())) {
			return;
		}
		Storage<ItemVariant> storage = pullTarget.find(Direction.DOWN);
		IItemHandler handler = storage == null ? null : new StorageItemHandler(storage);
		if (handler != null) {
			for (int i = 0, slots = handler.getSlots(); i < slots; i++) {
				ItemStack extractTest = handler.extractItem(i, Integer.MAX_VALUE, true);
				if (!extractTest.isEmpty()) {
					IItemHandler targetInv = SlotPredicates.FURNACE_FUEL.test(extractTest) ? fuelInv : inputInventory;
					transferItem(targetInv, i, extractTest, handler);
				}
			}
		}
	}

	private void pushToInventories(@NotNull Level level, @NotNull BlockPos pos) {
		if (pushTarget == null || outputInventory.isEmpty() || isHopper(level, pos.below())) {
			return;
		}
		Storage<ItemVariant> storage = pushTarget.find(Direction.UP);
		IItemHandler targetInv = storage == null ? null : new StorageItemHandler(storage);
		if (targetInv != null) {
			for (int i = 0, slots = outputInventory.getSlots(); i < slots; i++) {
				ItemStack extractTest = outputInventory.extractItem(i, Integer.MAX_VALUE, true);
				if (!extractTest.isEmpty()) {
					transferItem(targetInv, i, extractTest, outputInventory);
				}
			}
		}
	}

	private void transferItem(IItemHandler targetInv, int i, ItemStack extractTest, IItemHandler outputInventory) {
		ItemStack remainderTest = ItemHandlerHelper.insertItemStacked(targetInv, extractTest, true);
		int successfullyTransferred = extractTest.getCount() - remainderTest.getCount();
		if (successfullyTransferred > 0) {
			ItemStack toInsert = outputInventory.extractItem(i, successfullyTransferred, false);
			ItemStack result = ItemHandlerHelper.insertItemStacked(targetInv, toInsert, false);
			assert result.isEmpty();
		}
	}

	private RecipeResult getSmeltingRecipe(ItemStack input) {
		return getSmeltingRecipe(level, input);
	}

	private RecipeResult getSmeltingRecipe(@Nullable Level level, ItemStack input) {
		if (!(level instanceof ServerLevel serverLevel) || input.isEmpty()) {
			return RecipeResult.EMPTY;
		}
		//Note: We copy the input and fuel so that if anyone attempts to mutate the input from assemble then there is no side effects that occur
		SingleRecipeInput recipeInput = new SingleRecipeInput(input.copyWithCount(1));
		Optional<RecipeHolder<SmeltingRecipe>> optionalRecipe = quickCheck.getRecipeFor(recipeInput, serverLevel);
		if (optionalRecipe.isPresent()) {
			RecipeHolder<SmeltingRecipe> recipeHolder = optionalRecipe.get();
			return new RecipeResult(recipeHolder, recipeHolder.value().assemble(recipeInput));
		}
		return RecipeResult.EMPTY;
	}

	public boolean hasSmeltingResult(ItemStack input) {
		if (level != null && level.isClientSide()) {
			return level.recipeAccess().propertySet(RecipePropertySet.FURNACE_INPUT).test(input);
		}
		return getSmeltingRecipe(input).hasResult();
	}

	private void smeltItem(@NotNull Level level, @NotNull RecipeResult recipeResult) {
		ItemStack toSmelt = getItemToSmelt();
		ItemStack smeltResult = recipeResult.scaledResult(level.getRandom(), getDoubleChance(toSmelt));
		if (!smeltResult.isEmpty()) {//Double-check the result isn't somehow empty
			ItemHandlerHelper.insertItemStacked(outputInventory, smeltResult, false);

			if (toSmelt.is(Items.WET_SPONGE)) {
				//Hardcoded handling of wet sponge to filling a bucket with water
				ItemStack fuelItem = getFuelItem();
				if (!fuelItem.isEmpty() && fuelItem.is(Items.BUCKET)) {
					fuelInv.setStackInSlot(0, new ItemStack(Items.WATER_BUCKET));
				}
			}

			toSmelt.shrink(1);
			inputInventory.onContentsChanged(0);
			setRecipeUsed(recipeResult.recipeHolder());
		}
	}

	private boolean canSmelt(RecipeResult recipeResult) {
		ItemStack smeltResult = recipeResult.result();
		if (smeltResult.isEmpty()) {
			return false;
		}
		ItemStack currentSmelted = outputInventory.getStackInSlot(outputInventory.getSlots() - 1);
		if (currentSmelted.isEmpty()) {
			return true;
		} else if (!ItemStack.isSameItemSameComponents(smeltResult, currentSmelted)) {
			return false;
		}
		int result = currentSmelted.getCount() + smeltResult.getCount();
		return result <= currentSmelted.getMaxStackSize();
	}

	private int getItemBurnTime(@NotNull ServerLevel level, ItemStack stack) {
		if (!stack.has(DataComponents.COOKING_FUEL)) {
			return 0;
		}
		int burnTime = ResolvableInt.getFromItem(stack, DataComponents.COOKING_FUEL, CookingFuel::burnTime, getLootContext(level), 0);
		return burnTime * ticksBeforeSmelt / AbstractFurnaceBlockEntity.BURN_TIME_STANDARD * efficiencyBonus;
	}

	private LootContext getLootContext(@NotNull ServerLevel level) {
		return new LootContext.Builder(new LootParams.Builder(level)
				.withParameter(LootContextParams.BLOCK_STATE, getBlockState())
				.withParameter(LootContextParams.BLOCK_ENTITY, this)
				.withParameter(LootContextParams.ORIGIN, Vec3.atCenterOf(worldPosition))
				.withParameter(LootContextParams.CONTAINER, this)
				.create(LootContextParamSets.CONTAINER_PROCESS))
				.create(Optional.empty());
	}

	private int getTotalCookTime(RecipeResult recipeResult) {
		if (recipeResult.recipeHolder() == null) {
			return ticksBeforeSmelt;
		}
		int cookingTime = recipeResult.recipeHolder().value().cookingTime();
		return Mth.ceil(ticksBeforeSmelt * cookingTime / (float) AbstractFurnaceBlockEntity.BURN_TIME_STANDARD);
	}

	public float getLitProgress() {
		int litDuration = this.litDuration;
		if (litDuration == 0) {
			litDuration = ticksBeforeSmelt;
		}
		return Mth.clamp(litTime / (float) litDuration, 0, 1);
	}

	@Override
	public void loadAdditional(@NotNull ValueInput input) {
		super.loadAdditional(input);
		this.litTime = input.getIntOr("burn_time", 0);
		this.cookingProgress = input.getIntOr("cook_time", 0);
		this.cookingTotalTime = input.getIntOr("cook_time_total", 0);
		this.fuelInv.deserialize(input.childOrEmpty("fuel"));
		this.inputInventory.deserialize(input.childOrEmpty("input"));
		this.outputInventory.deserialize(input.childOrEmpty("output"));
		if (this.level instanceof ServerLevel serverLevel) {
			this.litDuration = getItemBurnTime(serverLevel, getFuelItem());
		}
		//[VanillaCopy] AbstractFurnaceBlockEntity
		this.recipesUsed.putAll(input.read("recipes_used", RECIPES_USED_CODEC).orElse(Map.of()));
	}

	@Override
	protected void saveAdditional(@NotNull ValueOutput output) {
		super.saveAdditional(output);
		output.putInt("burn_time", litTime);
		output.putInt("cook_time", cookingProgress);
		output.putInt("cook_time_total", this.cookingTotalTime);
		inputInventory.serialize(output.child("input"));
		outputInventory.serialize(output.child("output"));
		fuelInv.serialize(output.child("fuel"));
		//[VanillaCopy] AbstractFurnaceBlockEntity
		output.store("recipes_used", RECIPES_USED_CODEC, recipesUsed);
	}

	@Override
	public void setRecipeUsed(@Nullable RecipeHolder<?> recipeHolder) {
		//[VanillaCopy] AbstractFurnaceBlockEntity
		if (recipeHolder != null) {
			this.recipesUsed.addTo(recipeHolder.id(), 1);
		}
	}

	@Nullable
	@Override
	public RecipeHolder<?> getRecipeUsed() {
		//[VanillaCopy] AbstractFurnaceBlockEntity, always return null
		return null;
	}

	@Override
	public void awardUsedRecipes(@NotNull Player player, @NotNull List<ItemStack> items) {
		//[VanillaCopy] AbstractFurnaceBlockEntity, no-op
	}

	//[VanillaCopy] AbstractFurnaceBlockEntity
	public void awardUsedRecipesAndPopExperience(ServerPlayer player) {
		List<RecipeHolder<?>> recipes = getRecipesToAwardAndPopExperience(player.level(), player.position());
		player.awardRecipes(recipes);

		for (RecipeHolder<?> recipeholder : recipes) {
			//Note: We don't have a good way to access the list of input items that were present, so we just skip it
			// and only support triggering recipe triggers that are based on the recipe id
			player.triggerRecipeCrafted(recipeholder, Collections.emptyList());
		}

		this.recipesUsed.clear();
	}

	//[VanillaCopy] AbstractFurnaceBlockEntity
	public List<RecipeHolder<?>> getRecipesToAwardAndPopExperience(ServerLevel level, Vec3 popVec) {
		List<RecipeHolder<?>> list = new ArrayList<>();
		for (Iterator<Object2IntMap.Entry<ResourceKey<Recipe<?>>>> iterator = Object2IntMaps.fastIterator(recipesUsed); iterator.hasNext(); ) {
			Object2IntMap.Entry<ResourceKey<Recipe<?>>> entry = iterator.next();
			Optional<RecipeHolder<?>> optionalRecipe = level.recipeAccess().byKey(entry.getKey());
			if (optionalRecipe.isPresent()) {
				RecipeHolder<?> recipeHolder = optionalRecipe.get();
				list.add(recipeHolder);
				//Validate it is actually a cooking recipe
				if (recipeHolder.value() instanceof SmeltingRecipe recipe) {
					createExperience(level, popVec, entry.getIntValue(), recipe.experience());
				}
			}
		}
		return list;
	}

	//[VanillaCopy] AbstractFurnaceBlockEntity
	private static void createExperience(ServerLevel level, Vec3 popVec, int recipeIndex, float experience) {
		float indexBasedExperience = recipeIndex * experience;
		int amount = Mth.floor(indexBasedExperience);
		float partial = indexBasedExperience - amount;
		if (partial != 0.0F && Math.random() < (double) partial) {
			++amount;
		}

		ExperienceOrb.award(level, popVec, amount);
	}

	private record RecipeResult(@Nullable RecipeHolder<SmeltingRecipe> recipeHolder, ItemStack result) {

		private static final RecipeResult EMPTY = new RecipeResult(null, ItemStack.EMPTY);

		public ItemStack scaledResult(RandomSource random, float doubleChance) {
			if (random.nextFloat() < doubleChance) {
				return result.copyWithCount(2 * result.getCount());
			}
			return result.copy();
		}

		public boolean hasResult() {
			return !result.isEmpty();
		}
	}

	@Override
	public IItemHandler getFullHandler() {
		return this.joined;
	}

	@Override
	public IItemHandler getSideHandler(@org.jetbrains.annotations.Nullable net.minecraft.core.Direction side) {
		if (side == null) return this.joined;
		else if (side == net.minecraft.core.Direction.UP) return this.automationInput;
		else if (side == net.minecraft.core.Direction.DOWN) return this.automationOutput;
		return this.automationSides;
	}

}