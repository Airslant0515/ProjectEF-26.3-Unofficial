package moze_intel.projecte.gameObjs.blocks;

import java.util.function.Consumer;
import net.minecraft.network.chat.Component;
import org.jetbrains.annotations.NotNull;

/**
 * Implemented by blocks that want to contribute to the tooltip of their {@link net.minecraft.world.item.BlockItem} in MC 26.3, where
 * {@code Block}/{@code BlockBehaviour} no longer expose an {@code appendHoverText} hook. {@code moze_intel.projecte.events.ToolTipEvent}
 * invokes this for stacks whose item is a {@code BlockItem} wrapping this block.
 */
public interface ITooltipBlock {

	void appendTooltip(@NotNull Consumer<Component> tooltip);
}
