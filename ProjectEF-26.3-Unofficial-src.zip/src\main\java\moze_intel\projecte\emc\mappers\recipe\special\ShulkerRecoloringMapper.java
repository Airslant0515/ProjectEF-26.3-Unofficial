package moze_intel.projecte.emc.mappers.recipe.special;

import moze_intel.projecte.api.mapper.collector.IMappingCollector;
import moze_intel.projecte.api.mapper.recipe.INSSFakeGroupManager;
import moze_intel.projecte.api.mapper.recipe.RecipeTypeMapper;
import moze_intel.projecte.api.nss.NSSItem;
import moze_intel.projecte.api.nss.NormalizedSimpleStack;
import moze_intel.projecte.config.PEConfigTranslations;
import moze_intel.projecte.emc.mappers.recipe.BaseRecipeTypeMapper;
import moze_intel.projecte.utils.EMCHelper;
import net.minecraft.core.RegistryAccess;
import net.minecraft.core.registries.Registries;
import net.minecraft.resources.Identifier;
import net.minecraft.tags.TagKey;
import net.minecraft.world.item.DyeColor;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.Items;
import net.minecraft.world.item.crafting.TransmuteRecipe;
import net.minecraft.world.level.block.Block;
import net.minecraft.world.level.block.ShulkerBoxBlock;

@RecipeTypeMapper
public class ShulkerRecoloringMapper extends SpecialRecipeMapper<TransmuteRecipe> {

	@Override
	protected Class<TransmuteRecipe> getRecipeClass() {
		return TransmuteRecipe.class;
	}

	@Override
	protected boolean handleRecipe(IMappingCollector<NormalizedSimpleStack, Long> mapper, TransmuteRecipe recipe, RegistryAccess registryAccess,
			INSSFakeGroupManager fakeGroupManager) {
		//Note: In 26.3 shulker box recoloring is a transmute recipe instead of a dedicated ShulkerBoxColoring recipe
		ItemStack output = BaseRecipeTypeMapper.getResult(recipe, registryAccess);
		if (Block.byItem(output.getItem()) instanceof ShulkerBoxBlock shulkerBox) {
			DyeColor color = shulkerBox.getColor();
			if (color != null) {
				//DyeColor does not expose the conventional dye tag in vanilla, so build the same key the old (NeoForge) extension provided
				TagKey<Item> dyeTag = TagKey.create(Registries.ITEM, Identifier.fromNamespaceAndPath("c", "dyes/" + color.getName()));
				mapper.addConversion(1, NSSItem.createItem(output), EMCHelper.intMapOf(
						NSSItem.createItem(Items.SHULKER_BOX), 1,
						NSSItem.createTag(dyeTag), 1
				));
				return true;
			}
		}
		return false;
	}

	@Override
	public String getName() {
		return PEConfigTranslations.MAPPING_CRAFTING_MAPPER_SHULKER_RECOLORING.title();
	}

	@Override
	public String getTranslationKey() {
		return PEConfigTranslations.MAPPING_CRAFTING_MAPPER_SHULKER_RECOLORING.getTranslationKey();
	}

	@Override
	public String getDescription() {
		return PEConfigTranslations.MAPPING_CRAFTING_MAPPER_SHULKER_RECOLORING.tooltip();
	}
}
