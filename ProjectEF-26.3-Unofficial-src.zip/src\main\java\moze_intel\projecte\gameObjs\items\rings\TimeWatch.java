package moze_intel.projecte.gameObjs.items.rings;

import java.util.function.Consumer;
import com.mojang.serialization.Codec;
import io.netty.buffer.ByteBuf;
import java.util.ArrayList;
import java.util.List;
import java.util.Locale;
import java.util.function.IntFunction;
import java.util.function.Predicate;
import moze_intel.projecte.api.block_entity.IDMPedestal;
import moze_intel.projecte.api.capabilities.item.IItemCharge;
import moze_intel.projecte.api.capabilities.item.IPedestalItem;
import moze_intel.projecte.config.ProjectEConfig;
import moze_intel.projecte.gameObjs.PETags.BlockEntities;
import moze_intel.projecte.gameObjs.PETags.Blocks;
import moze_intel.projecte.gameObjs.items.IBarHelper;
import moze_intel.projecte.gameObjs.items.ICapabilityAware;
import moze_intel.projecte.gameObjs.registries.PEDataComponentTypes;
import moze_intel.projecte.integration.IntegrationHelper;
import moze_intel.projecte.utils.EMCHelper;
import moze_intel.projecte.utils.RegistryUtils;
import moze_intel.projecte.utils.WorldHelper;
import moze_intel.projecte.utils.text.ILangEntry;
import moze_intel.projecte.utils.text.PELang;
import net.minecraft.ChatFormatting;
import net.minecraft.core.BlockPos;
import net.minecraft.network.chat.Component;
import net.minecraft.network.codec.ByteBufCodecs;
import net.minecraft.network.codec.StreamCodec;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.util.ByIdMap;
import net.minecraft.util.StringRepresentable;
import net.minecraft.world.InteractionResult;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.Mob;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.TooltipFlag;
import net.minecraft.world.clock.WorldClocks;
import net.minecraft.world.level.gamerules.GameRules;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.block.entity.BlockEntity;
import net.minecraft.world.level.block.entity.BlockEntityTicker;
import net.minecraft.world.level.block.entity.BlockEntityType;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.level.material.FluidState;
import net.minecraft.world.phys.AABB;
import org.jetbrains.annotations.NotNull;
import net.minecraft.world.entity.EquipmentSlot;
import org.jetbrains.annotations.Nullable;
import net.minecraft.world.item.component.TooltipDisplay;

public class TimeWatch extends PEToggleItem implements IPedestalItem, IItemCharge, IBarHelper, ICapabilityAware {

	private static final Predicate<BlockEntity> VALID_TARGET = be -> !be.isRemoved() && be.hasLevel() && !RegistryUtils.getBEHolder(be.getType()).is(BlockEntities.BLACKLIST_TIME_WATCH);

	public TimeWatch(Properties props) {
		super(props.component(PEDataComponentTypes.CHARGE.get(), 0)
				.component(PEDataComponentTypes.STORED_EMC.get(), 0L)
				.component(PEDataComponentTypes.UNPROCESSED_EMC.get(), 0.0)
		);
	}

	@NotNull
	@Override
	public InteractionResult use(Level level, Player player, @NotNull InteractionHand hand) {
		ItemStack stack = player.getItemInHand(hand);
		if (!level.isClientSide()) {
			if (!ProjectEConfig.server.items.enableTimeWatch.get()) {
				player.sendSystemMessage(PELang.TIME_WATCH_DISABLED.translate());
				return InteractionResult.FAIL;
			}
			stack.update(PEDataComponentTypes.TIME_WATCH_MODE.get(), TimeWatchMode.OFF, TimeWatchMode::next);
			player.sendSystemMessage(PELang.TIME_WATCH_MODE_SWITCH.translate(getTimeName(stack)));
		}
		return InteractionResult.SUCCESS;
	}

	@Override
	public void inventoryTick(@NotNull ItemStack stack, @NotNull ServerLevel level, @NotNull Entity entity, @Nullable EquipmentSlot slot) {
		super.inventoryTick(stack, level, entity, slot);
		if (!(entity instanceof Player player) || !hotBarOrOffHand(stack, entity, slot) || !ProjectEConfig.server.items.enableTimeWatch.get()) {
			return;
		}
		TimeWatchMode timeControl = stack.getOrDefault(PEDataComponentTypes.TIME_WATCH_MODE.get(), TimeWatchMode.OFF);
		if (timeControl != TimeWatchMode.OFF && level.dimension() == Level.OVERWORLD && level.getGameRules().get(GameRules.ADVANCE_TIME)) {
			//Note: The clock manager clamps the resulting time to be at least zero, so rewinding past the start of time is fine
			int ticks = (int) (4L * (getCharge(stack) + 1));
			level.registryAccess().get(WorldClocks.OVERWORLD).ifPresent(clock ->
					level.clockManager().addTicks(clock, timeControl == TimeWatchMode.REWIND ? -ticks : ticks));
		}
		if (level.isClientSide() || !stack.getOrDefault(PEDataComponentTypes.ACTIVE.get(), false)) {
			return;
		}
		int charge = getCharge(stack);
		long reqEmc = EMCHelper.removeFractionalEMC(stack, getEmcPerTick(charge));
		if (!consumeFuel(player, stack, reqEmc, true)) {
			return;
		}
		int bonusTicks;
		float mobSlowdown;
		if (charge == 0) {
			bonusTicks = 8;
			mobSlowdown = 0.25F;
		} else if (charge == 1) {
			bonusTicks = 12;
			mobSlowdown = 0.16F;
		} else {
			bonusTicks = 16;
			mobSlowdown = 0.12F;
		}
		AABB effectBounds = player.getBoundingBox().inflate(8);
		speedUpBlocks(level, bonusTicks, effectBounds);
		slowMobs(level, effectBounds, mobSlowdown);
	}

	private void slowMobs(Level level, AABB effectBounds, double mobSlowdown) {
		if (mobSlowdown < 1) {
			for (Mob ent : level.getEntitiesOfClass(Mob.class, effectBounds)) {
				ent.setDeltaMovement(ent.getDeltaMovement().multiply(mobSlowdown, 1, mobSlowdown));
			}
		}
	}

	private void speedUpBlocks(Level level, int bonusTicks, AABB effectBounds) {
		if (bonusTicks > 0) {
			speedUpBlockEntities(level, bonusTicks, effectBounds);
			speedUpRandomTicks(level, bonusTicks, effectBounds);
		}
	}

	private void speedUpBlockEntities(Level level, int bonusTicks, AABB effectBounds) {
		for (BlockEntity blockEntity : WorldHelper.getBlockEntitiesWithinAABB(level, effectBounds, VALID_TARGET)) {
			BlockPos pos = blockEntity.getBlockPos();
			BlockState state = blockEntity.getBlockState();
			//Note: We get the ticker from the block state instead of the chunk's internal ticking wrappers as those
			// are not accessible, this also makes sure that we only tick the block entity if the chunk would tick it
			if (level.shouldTickBlocksAt(pos) && blockEntity.getType().isValid(state)) {
				provideBonusTicks(level, pos, state, blockEntity, bonusTicks);
			}
		}
	}

	@SuppressWarnings("unchecked")
	private <T extends BlockEntity> void provideBonusTicks(Level level, BlockPos pos, BlockState state, BlockEntity blockEntity, int bonusTicks) {
		BlockEntityTicker<T> ticker = state.getTicker(level, (BlockEntityType<T>) blockEntity.getType());
		if (ticker != null) {
			T be = (T) blockEntity;
			for (int i = 0; i < bonusTicks; i++) {
				ticker.tick(level, pos, state, be);
			}
		}
	}

	private void speedUpRandomTicks(Level level, int bonusTicks, AABB effectBounds) {
		if (!(level instanceof ServerLevel serverLevel)) {
			return;
		}
		for (BlockPos pos : WorldHelper.getPositionsInBox(effectBounds)) {
			if (WorldHelper.isBlockLoaded(level, pos)) {
				BlockState state = level.getBlockState(pos);
				if (state.isRandomlyTicking() && !state.is(Blocks.BLACKLIST_TIME_WATCH)) {
					FluidState fluidState = state.getFluidState();
					if (fluidState.isEmpty() || fluidState.isSource()) {// Don't speed non-source fluid blocks - dupe issues
						if (!WorldHelper.isCrop(state)) {// All plants should be sped using Harvest Goddess
							pos = pos.immutable();
							for (int i = 0; i < bonusTicks; i++) {
								state.randomTick(serverLevel, pos, level.getRandom());
							}
						}
					}
				}
			}
		}
	}

	private ILangEntry getTimeName(ItemStack stack) {
		return stack.getOrDefault(PEDataComponentTypes.TIME_WATCH_MODE.get(), TimeWatchMode.OFF).name;
	}

	public double getEmcPerTick(int charge) {
		return (charge + 2) / 2.0D;
	}

	@Override
	public void appendHoverText(@NotNull ItemStack stack, @NotNull Item.TooltipContext context, @NotNull TooltipDisplay display, @NotNull Consumer<Component> tooltip, @NotNull TooltipFlag flags) {
		super.appendHoverText(stack, context, display, tooltip, flags);
		tooltip.accept(PELang.TOOLTIP_TIME_WATCH_1.translate());
		tooltip.accept(PELang.TOOLTIP_TIME_WATCH_2.translate(Component.keybind("key.use")));
		tooltip.accept(PELang.TIME_WATCH_MODE.translate(getTimeName(stack)));
	}

	@Override
	public <PEDESTAL extends BlockEntity & IDMPedestal> boolean updateInPedestal(@NotNull ItemStack stack, @NotNull Level level, @NotNull BlockPos pos,
			@NotNull PEDESTAL pedestal) {
		// Change from old EE2 behaviour (universally increased tickrate) for safety and impl reasons.
		if (!level.isClientSide() && ProjectEConfig.server.items.enableTimeWatch.get()) {
			AABB effectBounds = pedestal.getEffectBounds();
			speedUpBlocks(level, ProjectEConfig.server.effects.timePedBonus.get(), effectBounds);
			slowMobs(level, effectBounds, ProjectEConfig.server.effects.timePedMobSlowness.get());
		}
		return false;
	}

	@NotNull
	@Override
	public List<Component> getPedestalDescription(float tickRate) {
		List<Component> list = new ArrayList<>();
		if (ProjectEConfig.server.effects.timePedBonus.get() > 0) {
			list.add(PELang.PEDESTAL_TIME_WATCH_1.translateColored(ChatFormatting.BLUE, ProjectEConfig.server.effects.timePedBonus.get()));
		}
		if (ProjectEConfig.server.effects.timePedMobSlowness.get() < 1.0F) {
			list.add(PELang.PEDESTAL_TIME_WATCH_2.translateColored(ChatFormatting.BLUE, String.format("%.3f", ProjectEConfig.server.effects.timePedMobSlowness.get())));
		}
		return list;
	}

	@Override
	public int getNumCharges(@NotNull ItemStack stack) {
		return 2;
	}

	@Override
	public boolean isBarVisible(@NotNull ItemStack stack) {
		return true;
	}

	@Override
	public float getWidthForBar(ItemStack stack) {
		return 1 - getChargePercent(stack);
	}

	@Override
	public int getBarWidth(@NotNull ItemStack stack) {
		return getScaledBarWidth(stack);
	}

	@Override
	public int getBarColor(@NotNull ItemStack stack) {
		return getColorForBar(stack);
	}

	@Override
	public void attachCapabilities() {
		IntegrationHelper.registerCuriosCapability(this);
	}

	public enum TimeWatchMode implements StringRepresentable {
		OFF(PELang.TIME_WATCH_OFF),
		FAST_FORWARD(PELang.TIME_WATCH_FAST_FORWARD),
		REWIND(PELang.TIME_WATCH_REWIND);

		public static final Codec<TimeWatchMode> CODEC = StringRepresentable.fromEnum(TimeWatchMode::values);
		public static final IntFunction<TimeWatchMode> BY_ID = ByIdMap.continuous(TimeWatchMode::ordinal, values(), ByIdMap.OutOfBoundsStrategy.WRAP);
		public static final StreamCodec<ByteBuf, TimeWatchMode> STREAM_CODEC = ByteBufCodecs.idMapper(BY_ID, TimeWatchMode::ordinal);

		private final String serializedName;
		private final ILangEntry name;

		TimeWatchMode(ILangEntry name) {
			this.serializedName = name().toLowerCase(Locale.ROOT);
			this.name = name;
		}

		@NotNull
		@Override
		public String getSerializedName() {
			return serializedName;
		}

		public TimeWatchMode next() {
			return switch (this) {
				case OFF -> FAST_FORWARD;
				case FAST_FORWARD -> REWIND;
				case REWIND -> OFF;
			};
		}
	}
}