package moze_intel.projecte.impl.capability;

import com.mojang.serialization.Codec;
import java.util.EnumMap;
import java.util.Map;
import java.util.Set;
import moze_intel.projecte.PECore;
import moze_intel.projecte.api.capabilities.IAlchBagProvider;
import moze_intel.projecte.gameObjs.registries.PEAttachmentTypes;
import moze_intel.projecte.impl.codec.PECodecHelper;
import moze_intel.projecte.network.PEStreamCodecs;
import moze_intel.projecte.network.packets.to_client.alch_bag.SyncAllBagDataPKT;
import moze_intel.projecte.network.packets.to_client.alch_bag.SyncBagsDataPKT;
import net.fabricmc.fabric.api.attachment.v1.AttachmentTarget;
import net.minecraft.network.RegistryFriendlyByteBuf;
import net.minecraft.network.codec.ByteBufCodecs;
import net.minecraft.network.codec.StreamCodec;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.DyeColor;
import moze_intel.projecte.api.item_handlers.IItemHandler;
import moze_intel.projecte.api.item_handlers.ItemStackHandler;
import moze_intel.projecte.network.PENetwork;
import org.jetbrains.annotations.NotNull;
public final class AlchBagImpl implements IAlchBagProvider {

	private final Player player;

	public AlchBagImpl(Player player) {
		this.player = player;
	}

	private AlchemicalBagAttachment attachment() {
		//Fabric injects AttachmentTarget into Entity (and thus Player) as a transitive interface via its access widener, so the cast is a no-op at runtime
		return ((AttachmentTarget) this.player).getAttachedOrCreate(PEAttachmentTypes.ALCHEMICAL_BAGS);
	}

	@NotNull
	@Override
	public IItemHandler getBag(@NotNull DyeColor color) {
		return attachment().getBag(color);
	}

	@Override
	public void sync(@NotNull ServerPlayer player, @NotNull Set<DyeColor> colors) {
		if (!colors.isEmpty()) {
			AlchemicalBagAttachment attachment = attachment();
			Map<DyeColor, ItemStackHandler> handlers = new EnumMap<>(DyeColor.class);
			for (DyeColor color : colors) {
				handlers.put(color, attachment.getBag(color));
			}
			PENetwork.sendToPlayer(player, new SyncBagsDataPKT(handlers));
		}
	}

	@Override
	public void syncAllBags(@NotNull ServerPlayer player) {
		PENetwork.sendToPlayer(player, new SyncAllBagDataPKT(attachment()));
	}

	public static class AlchemicalBagAttachment {

		private static final int BAG_SIZE = 104;
		public static final Codec<AlchemicalBagAttachment> CODEC = Codec.unboundedMap(DyeColor.CODEC, PECodecHelper.MUTABLE_HANDLER_CODEC).xmap(
				map -> new AlchemicalBagAttachment(map.isEmpty() ? new EnumMap<>(DyeColor.class) : new EnumMap<>(map)),
				attachment -> attachment.inventories
		);
		public static final StreamCodec<RegistryFriendlyByteBuf, Map<DyeColor, ItemStackHandler>> MAP_STREAM_CODEC = ByteBufCodecs.map(
				ignored -> new EnumMap<>(DyeColor.class),
				DyeColor.STREAM_CODEC,
				PEStreamCodecs.handlerStreamCodec(BAG_SIZE)
		);
		public static final StreamCodec<RegistryFriendlyByteBuf, AlchemicalBagAttachment> STREAM_CODEC = MAP_STREAM_CODEC.map(
				AlchemicalBagAttachment::new, attachment -> attachment.inventories
		);

		private final Map<DyeColor, ItemStackHandler> inventories;

		public AlchemicalBagAttachment() {
			this(new EnumMap<>(DyeColor.class));
		}

		private AlchemicalBagAttachment(Map<DyeColor, ItemStackHandler> inventories) {
			this.inventories = inventories;
		}



		@NotNull
		public ItemStackHandler getBag(@NotNull DyeColor color) {
			return inventories.computeIfAbsent(color, c -> new ItemStackHandler(BAG_SIZE));
		}

		public void updateBags(Map<DyeColor, ItemStackHandler> handlers) {
			for (Map.Entry<DyeColor, ItemStackHandler> entry : handlers.entrySet()) {
				DyeColor color = entry.getKey();
				ItemStackHandler handler = entry.getValue();
				if (handler.getSlots() == BAG_SIZE) {
					inventories.put(color, handler);
				} else {
					PECore.LOGGER.warn("Received packet for updating {}, but the handler was of the wrong size. Expected: {}, Received: {}", color, BAG_SIZE, handler.getSlots());
				}
			}
		}
	}
}