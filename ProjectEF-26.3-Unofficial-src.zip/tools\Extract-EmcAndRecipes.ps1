﻿#Requires -Version 5.1
<#
.SYNOPSIS
    Extract recipes, world transmutations, custom conversions and EMC overrides from built jars,
    for inspection / translation / cross-checking ports.

.DESCRIPTION
    Safety rules baked into this script:
      * Everything it writes or deletes lives under  <repo>\tmp\ .
      * It refuses to run if the output directory resolves outside  <repo>\tmp\ .
      * It refuses to delete anything that is not a directory it created itself
        (name starts with  export-  or  _unpacked-  and is directly under tmp\).
      * It never touches the mod's own data/ directory, never touches the game instance,
        and never terminates any process (no  Stop-Process , no  taskkill ).

.PARAMETER JarPath
    Path to a mod jar, or to a directory containing jars. Defaults to the newest
    jar under build\libs.

.PARAMETER OutDir
    Output directory. Must be inside <repo>\tmp\. Defaults to tmp\export-<timestamp>.

.PARAMETER KeepUnpacked
    Keep the temporary unpack directory instead of removing it after the export.

.EXAMPLE
    powershell -ExecutionPolicy Bypass -File .\tools\Extract-EmcAndRecipes.ps1

.EXAMPLE
    powershell -ExecutionPolicy Bypass -File .\tools\Extract-EmcAndRecipes.ps1 `
        -JarPath .\build\libs -OutDir .\tmp\export-check
#>
[CmdletBinding()]
param(
    [string]$JarPath = '',
    [string]$OutDir = '',
    [string]$EmcJsonPath = '',
    [switch]$KeepUnpacked
)

Set-StrictMode -Version Latest
$ErrorActionPreference = 'Stop'

function Get-RepoRoot {
    return (Split-Path -Parent $PSScriptRoot)
}

function Assert-UnderTmp {
    param([string]$Path, [string]$TmpRoot)
    $full = [System.IO.Path]::GetFullPath($Path)
    $tmpFull = [System.IO.Path]::GetFullPath($TmpRoot).TrimEnd('\') + '\'
    if (-not $full.StartsWith($tmpFull, [System.StringComparison]::OrdinalIgnoreCase)) {
        throw "拒绝执行：路径不在 tmp\ 下 -> $full (允许范围: $tmpFull)"
    }
    return $full
}

$repoRoot = Get-RepoRoot
$tmpRoot = Join-Path $repoRoot 'tmp'
if (-not (Test-Path -LiteralPath $tmpRoot)) {
    New-Item -ItemType Directory -Path $tmpRoot -Force | Out-Null
}
$tmpRootFull = [System.IO.Path]::GetFullPath($tmpRoot)
Write-Host "[info] repo root : $repoRoot"
Write-Host "[info] tmp root  : $tmpRootFull"

# ---- resolve input jars ---------------------------------------------------
if ([string]::IsNullOrWhiteSpace($JarPath)) {
    $libsDir = Join-Path $repoRoot 'build\libs'
    if (-not (Test-Path -LiteralPath $libsDir)) {
        throw "找不到 build\libs，请先构建，或用 -JarPath 指定 jar。"
    }
    $candidate = Get-ChildItem -LiteralPath $libsDir -Filter '*.jar' -File |
        Where-Object { $_.Name -notmatch 'sources|api|javadoc' } |
        Sort-Object LastWriteTime -Descending |
        Select-Object -First 1
    if ($null -eq $candidate) {
        throw "build\libs 里没有可用的 jar，请先构建。"
    }
    $jars = @($candidate.FullName)
} elseif (Test-Path -LiteralPath $JarPath -PathType Container) {
    $jars = @(Get-ChildItem -LiteralPath $JarPath -Filter '*.jar' -File |
        Where-Object { $_.Name -notmatch 'sources|api|javadoc' } |
        Sort-Object Name |
        ForEach-Object { $_.FullName })
} elseif (Test-Path -LiteralPath $JarPath -PathType Leaf) {
    $jars = @((Resolve-Path -LiteralPath $JarPath).Path)
} else {
    throw "找不到 jar 或目录: $JarPath"
}
if ($jars.Count -eq 0) {
    throw "没有找到任何 jar。"
}

# ---- resolve output dir ---------------------------------------------------
if ([string]::IsNullOrWhiteSpace($OutDir)) {
    $stamp = Get-Date -Format 'yyyyMMdd-HHmmss'
    $OutDir = Join-Path $tmpRoot "export-$stamp"
}
if ([System.IO.Path]::IsPathRooted($OutDir)) {
    $outFull = [System.IO.Path]::GetFullPath($OutDir)
} else {
    $outFull = [System.IO.Path]::GetFullPath((Join-Path $repoRoot $OutDir))
}
$outFull = Assert-UnderTmp -Path $outFull -TmpRoot $tmpRootFull
New-Item -ItemType Directory -Path $outFull -Force | Out-Null
Write-Host "[info] out dir   : $outFull"

Add-Type -AssemblyName System.IO.Compression.FileSystem

$recipeRows = New-Object System.Collections.Generic.List[object]
$emcRows = New-Object System.Collections.Generic.List[object]

foreach ($jar in $jars) {
    $jarName = [System.IO.Path]::GetFileNameWithoutExtension($jar)
    $stamp = Get-Date -Format 'yyyyMMdd-HHmmss'
    $unpack = Join-Path $tmpRoot "_unpacked-$stamp-$jarName"
    $unpack = Assert-UnderTmp -Path $unpack -TmpRoot $tmpRootFull
    Write-Host "[info] unpacking $([System.IO.Path]::GetFileName($jar)) -> $unpack"
    [System.IO.Compression.ZipFile]::ExtractToDirectory($jar, $unpack)

    # ---- data pack content ----
    $copyMap = @(
        @{ Pattern = 'data/*/recipe';            Sub = 'recipes';   Desc = '配方' },
        @{ Pattern = 'data/*/pe_world_transmutations'; Sub = 'world_transmutations'; Desc = '世界转换' },
        @{ Pattern = 'data/*/pe_custom_conversions';  Sub = 'custom_conversions';  Desc = '自定义转换' }
    )
    foreach ($entry in $copyMap) {
        $parts = $entry.Pattern.Split('/')
        $nsDirs = Get-ChildItem -LiteralPath (Join-Path $unpack $parts[0]) -Directory -ErrorAction SilentlyContinue
        foreach ($nsDir in $nsDirs) {
            $srcDir = Join-Path $nsDir.FullName $parts[2]
            if (-not (Test-Path -LiteralPath $srcDir)) { continue }
            $destDir = Join-Path (Join-Path $outFull $entry.Sub) $nsDir.Name
            New-Item -ItemType Directory -Path $destDir -Force | Out-Null
            Copy-Item -LiteralPath (Join-Path $srcDir '*') -Destination $destDir -Recurse -Force
            Write-Host "  [ok] $($entry.Desc): $($nsDir.Name) ($((Get-ChildItem -LiteralPath $srcDir -Recurse -File).Count) 个文件)"
        }
    }

    # ---- language files ----
    $langDir = Join-Path $unpack 'assets\projecte\lang'
    if (Test-Path -LiteralPath $langDir) {
        $destLang = Join-Path $outFull 'lang'
        New-Item -ItemType Directory -Path $destLang -Force | Out-Null
        Copy-Item -LiteralPath (Join-Path $langDir '*') -Destination $destLang -Recurse -Force
        Write-Host "  [ok] 语言文件: $((Get-ChildItem -LiteralPath $langDir -File).Count) 个"
    }

    # ---- recipes -> CSV ----
    $recipeRoot = Join-Path $unpack 'data'
    if (Test-Path -LiteralPath $recipeRoot) {
        $recipeFiles = Get-ChildItem -LiteralPath $recipeRoot -Recurse -File -Filter '*.json' |
            Where-Object { $_.DirectoryName -match '\\recipe(\\|$)' }
        foreach ($rf in $recipeFiles) {
            try {
                $json = Get-Content -LiteralPath $rf.FullName -Raw -Encoding UTF8 | ConvertFrom-Json
            } catch {
                continue
            }
            $type = ''
            if ($null -ne $json.PSObject.Properties['type']) { $type = [string]$json.type }
            $resultId = ''
            $resultCount = ''
            $resultProp = $json.PSObject.Properties['result']
            if ($null -ne $resultProp -and $null -ne $resultProp.Value) {
                $res = $resultProp.Value
                if ($res -is [string]) {
                    $resultId = [string]$res
                } else {
                    if ($null -ne $res.PSObject.Properties['id']) { $resultId = [string]$res.id }
                    elseif ($null -ne $res.PSObject.Properties['item']) { $resultId = [string]$res.item }
                    if ($null -ne $res.PSObject.Properties['count']) { $resultCount = [string]$res.count }
                }
            }
            $rel = $rf.FullName.Substring($recipeRoot.Length).TrimStart('\')
            $recipeRows.Add([pscustomobject]@{
                jar     = $jarName
                id      = ($rel -replace '\\', '/' -replace '^.*?/recipe/', '' -replace '\.json$', '')
                type    = $type
                result  = $resultId
                count   = $resultCount
            })
        }
    }

    # ---- any EMC-looking json (custom_emc.json / *emc*.json) ----
    $emcFiles = Get-ChildItem -LiteralPath $unpack -Recurse -File -Filter '*.json' |
        Where-Object { $_.Name -match 'emc' }
    foreach ($ef in $emcFiles) {
        try {
            $doc = Get-Content -LiteralPath $ef.FullName -Raw -Encoding UTF8 | ConvertFrom-Json
        } catch {
            continue
        }
        $entriesProp = $doc.PSObject.Properties['entries']
        if ($null -ne $entriesProp -and $null -ne $entriesProp.Value) {
            foreach ($prop in $entriesProp.Value.PSObject.Properties) {
                $value = $prop.Value
                $emc = ''
                if ($null -ne $value -and $null -ne $value.PSObject.Properties['emc']) {
                    $emc = [string]$value.emc
                }
                $emcRows.Add([pscustomobject]@{
                    jar    = $jarName
                    source = $ef.Name
                    key    = $prop.Name
                    emc    = $emc
                })
            }
        }
    }

    if (-not $KeepUnpacked) {
        $unpackCheck = Assert-UnderTmp -Path $unpack -TmpRoot $tmpRootFull
        $leaf = Split-Path -Leaf $unpackCheck
        if ($leaf -like '_unpacked-*') {
            Remove-Item -LiteralPath $unpackCheck -Recurse -Force
            Write-Host "  [ok] 已清理解压临时目录: $leaf"
        }
    }
}

# ---- optional: read EMC override files from a game/config directory ---------
# The full EMC table is computed at runtime from recipes; the JSON files only hold
# overrides (custom_emc.json) so point this at a config/ProjectE folder to collect them.
if ([string]::IsNullOrWhiteSpace($EmcJsonPath)) {
    $defaultCfg = Join-Path $repoRoot 'run\config\ProjectE'
    if (Test-Path -LiteralPath $defaultCfg) { $EmcJsonPath = $defaultCfg }
}
if (-not [string]::IsNullOrWhiteSpace($EmcJsonPath) -and (Test-Path -LiteralPath $EmcJsonPath)) {
    $extFiles = @()
    if (Test-Path -LiteralPath $EmcJsonPath -PathType Container) {
        $extFiles = @(Get-ChildItem -LiteralPath $EmcJsonPath -Recurse -File -Filter '*.json' |
            Where-Object { $_.Name -match 'emc' })
    } else {
        $extFiles = @(Get-Item -LiteralPath $EmcJsonPath)
    }
    foreach ($ef in $extFiles) {
        try {
            $doc = Get-Content -LiteralPath $ef.FullName -Raw -Encoding UTF8 | ConvertFrom-Json
        } catch {
            Write-Warning "跳过无法解析的 EMC 文件: $($ef.FullName)"
            continue
        }
        $entriesProp = $doc.PSObject.Properties['entries']
        if ($null -eq $entriesProp -or $null -eq $entriesProp.Value) { continue }
        foreach ($prop in $entriesProp.Value.PSObject.Properties) {
            $value = $prop.Value
            $emc = ''
            if ($null -ne $value -and $null -ne $value.PSObject.Properties['emc']) {
                $emc = [string]$value.emc
            }
            $emcRows.Add([pscustomobject]@{
                jar    = '(external)'
                source = $ef.Name
                key    = $prop.Name
                emc    = $emc
            })
        }
        Write-Host "  [ok] EMC 覆盖文件: $($ef.Name)（$($entriesProp.Value.PSObject.Properties.Count) 条）"
    }
}

# ---- write reports --------------------------------------------------------
$recipeCsv = Join-Path $outFull 'recipes.csv'
$emcCsv = Join-Path $outFull 'emc-values.csv'
if ($recipeRows.Count -gt 0) {
    $recipeRows | Export-Csv -LiteralPath $recipeCsv -NoTypeInformation -Encoding UTF8
} else {
    Set-Content -LiteralPath $recipeCsv -Value 'jar,id,type,result,count' -Encoding UTF8
}
if ($emcRows.Count -gt 0) {
    $emcRows | Export-Csv -LiteralPath $emcCsv -NoTypeInformation -Encoding UTF8
} else {
    Set-Content -LiteralPath $emcCsv -Value 'jar,source,key,emc' -Encoding UTF8
}

$summary = @()
$summary += "# EMC / recipe export"
$summary += ""
$summary += "- 生成时间: $(Get-Date -Format 'yyyy-MM-dd HH:mm:ss')"
$summary += "- 来源 jar: $($jars.Count) 个"
foreach ($j in $jars) { $summary += "  - $(Split-Path -Leaf $j)" }
$summary += "- 配方条目: $($recipeRows.Count)  -> recipes.csv"
$summary += "- EMC 条目: $($emcRows.Count)  -> emc-values.csv"
$summary += ""
$summary += "本目录仅用于查看/对照，不会影响游戏。"
$summaryPath = Join-Path $outFull 'README.txt'
Set-Content -LiteralPath $summaryPath -Value ($summary -join "`r`n") -Encoding UTF8

Write-Host ""
Write-Host "[done] 导出完成: $outFull"
Write-Host "       配方 $($recipeRows.Count) 条 -> recipes.csv"
Write-Host "       EMC  $($emcRows.Count) 条 -> emc-values.csv"
Write-Host "       清理: powershell -ExecutionPolicy Bypass -File .\tools\Clear-Temp.ps1"
