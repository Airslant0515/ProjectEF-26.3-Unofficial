package moze_intel.projecte.gameObjs;

import com.mojang.serialization.Codec;
import net.minecraft.tags.ItemTags;
import net.minecraft.tags.TagKey;
import net.minecraft.util.StringRepresentable;
import net.minecraft.world.item.ToolMaterial;
import net.minecraft.world.level.block.Block;
import net.minecraft.world.level.material.MapColor;
import org.jetbrains.annotations.NotNull;

public enum EnumMatterType implements StringRepresentable, IMatterType {
	DARK_MATTER("dark_matter", 3, 14, 12, PETags.Blocks.INCORRECT_FOR_DARK_MATTER_TOOL, MapColor.COLOR_BLACK),
	RED_MATTER("red_matter", 4, 16, 14, PETags.Blocks.INCORRECT_FOR_RED_MATTER_TOOL, MapColor.COLOR_RED);

	public static final Codec<EnumMatterType> CODEC = StringRepresentable.fromEnum(EnumMatterType::values);

	private final ToolMaterial toolMaterial;
	private final String name;
	private final float chargeModifier;
	private final MapColor mapColor;

	EnumMatterType(String name, float attackDamage, float efficiency, float chargeModifier, TagKey<Block> incorrectBlockForDrops, MapColor mapColor) {
		this.name = name;
		this.chargeModifier = chargeModifier;
		this.mapColor = mapColor;
		//Durability is intentionally zero: ProjectE matter tools/armor never take durability damage and their properties suppress the durability component.
		this.toolMaterial = new ToolMaterial(incorrectBlockForDrops, 0, efficiency, attackDamage, 1, ItemTags.NETHERITE_TOOL_MATERIALS);
	}

	@NotNull
	@Override
	public String getSerializedName() {
		return name;
	}

	@Override
	public String toString() {
		return getSerializedName();
	}

	@Override
	public ToolMaterial getToolMaterial() {
		return toolMaterial;
	}

	@Override
	public float getChargeModifier() {
		return chargeModifier;
	}

	public MapColor getMapColor() {
		return mapColor;
	}

	@Override
	public int getMatterTier() {
		return ordinal();
	}
}
