package moze_intel.projecte.gameObjs.registration.impl;

import java.util.function.BiFunction;
import java.util.function.Function;
import java.util.function.Supplier;
import moze_intel.projecte.gameObjs.registration.DoubleDeferredRegister;
import moze_intel.projecte.gameObjs.registration.PEDeferredHolder;
import moze_intel.projecte.gameObjs.registration.impl.BlockRegistryObject.WallOrFloorBlockRegistryObject;
import net.minecraft.core.Direction;
import net.minecraft.core.registries.Registries;
import net.minecraft.resources.Identifier;
import net.minecraft.resources.ResourceKey;
import net.minecraft.world.item.BlockItem;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.StandingAndWallBlockItem;
import net.minecraft.world.level.block.Block;
import net.minecraft.world.level.block.state.BlockBehaviour;
import org.jetbrains.annotations.NotNull;

public class BlockDeferredRegister extends DoubleDeferredRegister<Block, Item> {

	public BlockDeferredRegister(String modid) {
		super(Registries.BLOCK, new ItemDeferredRegister(modid), modid);
	}

	public <BLOCK extends Block> BlockRegistryObject<BLOCK, BlockItem> register(String name, Function<BlockBehaviour.Properties, ? extends BLOCK> blockCreator) {
		return register(name, blockCreator, BlockItem::new);
	}

	/**
	 * Registers a block and its item. The properties the block creator receives have already been given the block's id, as modern versions require the id to be
	 * known before the block instance is created.
	 */
	public <BLOCK extends Block, ITEM extends BlockItem> BlockRegistryObject<BLOCK, ITEM> register(String name,
			Function<BlockBehaviour.Properties, ? extends BLOCK> blockCreator, BiFunction<BLOCK, Item.Properties, ITEM> itemCreator) {
		return register(name, () -> blockCreator.apply(blockProperties(name)), block -> itemCreator.apply(block, itemProperties(name)), BlockRegistryObject::new);
	}

	public <BLOCK extends Block, WALL_BLOCK extends Block> WallOrFloorBlockRegistryObject<BLOCK, WALL_BLOCK, StandingAndWallBlockItem> registerWallOrFloorItem(String name,
			Function<BlockBehaviour.Properties, BLOCK> blockCreator, Function<BlockBehaviour.Properties, WALL_BLOCK> wallBlockCreator,
			BlockBehaviour.Properties baseProperties) {
		//Note: By the time the wall block's factory runs during registration, the floor block has already been registered, so we can safely access it
		PEDeferredHolder<Block, BLOCK> primaryObject = primaryRegister.register(name, () -> blockCreator.apply(baseProperties.setId(blockId(name))));
		PEDeferredHolder<Block, WALL_BLOCK> wallObject = primaryRegister.register("wall_" + name,
				() -> wallBlockCreator.apply(baseProperties.setId(blockId("wall_" + name)).overrideLootTable(primaryObject.get().getLootTable())));
		return new WallOrFloorBlockRegistryObject<>(primaryObject, wallObject, secondaryRegister.register(name,
				() -> new StandingAndWallBlockItem(primaryObject.get(), wallObject.get(), Direction.DOWN, itemProperties(name))));
	}

	public <BLOCK extends Block, ITEM extends BlockItem> BlockRegistryObject<BLOCK, ITEM> register(String name, Supplier<? extends BLOCK> blockSupplier,
			Function<BLOCK, ITEM> itemCreator) {
		return register(name, blockSupplier, itemCreator, BlockRegistryObject::new);
	}

	@NotNull
	public String getNamespace() {
		return primaryRegister.getNamespace();
	}

	@NotNull
	private BlockBehaviour.Properties blockProperties(String name) {
		return BlockBehaviour.Properties.of().setId(blockId(name));
	}

	@NotNull
	private ResourceKey<Block> blockId(String name) {
		return ResourceKey.create(Registries.BLOCK, Identifier.fromNamespaceAndPath(getNamespace(), name));
	}

	@NotNull
	private Item.Properties itemProperties(String name) {
		return new Item.Properties().setId(ResourceKey.create(Registries.ITEM, Identifier.fromNamespaceAndPath(getNamespace(), name))).useBlockDescriptionPrefix();
	}
}
