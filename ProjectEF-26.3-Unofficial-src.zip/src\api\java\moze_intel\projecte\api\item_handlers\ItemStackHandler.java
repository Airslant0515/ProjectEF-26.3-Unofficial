package moze_intel.projecte.api.item_handlers;

import java.util.List;
import net.minecraft.core.HolderLookup;
import net.minecraft.core.NonNullList;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.nbt.NbtOps;
import net.minecraft.nbt.Tag;
import net.minecraft.resources.RegistryOps;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.ItemStack;
import org.jetbrains.annotations.NotNull;

/**
 * A simple {@link IItemHandlerModifiable} implementation backed by a {@link NonNullList} of stacks.
 */
public class ItemStackHandler implements IItemHandlerModifiable {

	protected NonNullList<ItemStack> stacks;

	public ItemStackHandler() {
		this(1);
	}

	public ItemStackHandler(int size) {
		this.stacks = NonNullList.withSize(size, ItemStack.EMPTY);
	}

	public ItemStackHandler(NonNullList<ItemStack> stacks) {
		this.stacks = stacks;
	}

	public void setSize(int size) {
		this.stacks = NonNullList.withSize(size, ItemStack.EMPTY);
	}

	/**
	 * Exposes the backing list of this handler for serialization purposes. Do not modify the size of the returned list.
	 */
	public NonNullList<ItemStack> getStacks() {
		return stacks;
	}

	@Override
	public int getSlots() {
		return stacks.size();
	}

	@NotNull
	@Override
	public ItemStack getStackInSlot(int slot) {
		validateSlotIndex(slot);
		return stacks.get(slot);
	}

	@Override
	public void setStackInSlot(int slot, @NotNull ItemStack stack) {
		validateSlotIndex(slot);
		stacks.set(slot, stack);
		onContentsChanged(slot);
	}

	@NotNull
	@Override
	public ItemStack insertItem(int slot, @NotNull ItemStack stack, boolean simulate) {
		if (stack.isEmpty()) {
			return ItemStack.EMPTY;
		} else if (!isItemValid(slot, stack)) {
			return stack;
		}
		validateSlotIndex(slot);
		ItemStack existing = stacks.get(slot);
		int limit = Math.min(getSlotLimit(slot), stack.getMaxStackSize());
		if (!existing.isEmpty()) {
			if (!ItemStack.isSameItemSameComponents(stack, existing)) {
				return stack;
			}
			limit -= existing.getCount();
		}
		if (limit <= 0) {
			return stack;
		}
		boolean reachedLimit = stack.getCount() > limit;
		if (!simulate) {
			if (existing.isEmpty()) {
				stacks.set(slot, reachedLimit ? stack.copyWithCount(limit) : stack.copy());
			} else {
				existing.grow(reachedLimit ? limit : stack.getCount());
			}
			onContentsChanged(slot);
		}
		return reachedLimit ? stack.copyWithCount(stack.getCount() - limit) : ItemStack.EMPTY;
	}

	@NotNull
	@Override
	public ItemStack extractItem(int slot, int amount, boolean simulate) {
		if (amount == 0) {
			return ItemStack.EMPTY;
		}
		validateSlotIndex(slot);
		ItemStack existing = stacks.get(slot);
		if (existing.isEmpty()) {
			return ItemStack.EMPTY;
		}
		int toExtract = Math.min(amount, existing.getMaxStackSize());
		if (existing.getCount() <= toExtract) {
			if (!simulate) {
				stacks.set(slot, ItemStack.EMPTY);
				onContentsChanged(slot);
			}
			return existing.copy();
		}
		if (!simulate) {
			stacks.set(slot, existing.copyWithCount(existing.getCount() - toExtract));
			onContentsChanged(slot);
		}
		return existing.copyWithCount(toExtract);
	}

	@Override
	public int getSlotLimit(int slot) {
		return Item.ABSOLUTE_MAX_STACK_SIZE;
	}

	@Override
	public boolean isItemValid(int slot, @NotNull ItemStack stack) {
		return true;
	}

	/**
	 * Bridges the public in-place mutation signal onto this class' existing {@link #onContentsChanged(int)} hook, so that
	 * subclasses reacting to content changes (marking a block entity dirty, recalculating EMC, ...) also see mutations
	 * that bypassed {@link #insertItem(int, ItemStack, boolean)} / {@link #extractItem(int, int, boolean)}.
	 */
	@Override
	public void markSlotChanged(int slot) {
		validateSlotIndex(slot);
		onContentsChanged(slot);
	}

	public CompoundTag serializeNBT(HolderLookup.Provider provider) {
		CompoundTag nbt = new CompoundTag();
		nbt.putInt("Size", stacks.size());
		RegistryOps<Tag> ops = provider.createSerializationContext(NbtOps.INSTANCE);
		nbt.store("Items", ItemStack.OPTIONAL_CODEC.listOf(), ops, stacks);
		return nbt;
	}

	public void deserializeNBT(HolderLookup.Provider provider, CompoundTag nbt) {
		setSize(nbt.getIntOr("Size", stacks.size()));
		RegistryOps<Tag> ops = provider.createSerializationContext(NbtOps.INSTANCE);
		List<ItemStack> items = nbt.read("Items", ItemStack.OPTIONAL_CODEC.listOf(), ops).orElse(List.of());
		for (int slot = 0; slot < Math.min(items.size(), stacks.size()); slot++) {
			stacks.set(slot, items.get(slot));
		}
		onLoad();
	}

	protected void validateSlotIndex(int slot) {
		if (slot < 0 || slot >= stacks.size()) {
			throw new IndexOutOfBoundsException("Slot " + slot + " not in valid range - [0," + stacks.size() + ")");
		}
	}

	protected void onLoad() {
	}

	protected void onContentsChanged(int slot) {
	}
}
