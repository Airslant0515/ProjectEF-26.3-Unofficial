package moze_intel.projecte.gameObjs.items.armor;

import java.util.function.Consumer;
import moze_intel.projecte.PECore;
import moze_intel.projecte.gameObjs.items.IHasConditionalAttributes;
import moze_intel.projecte.gameObjs.registries.PEDataComponentTypes;
import moze_intel.projecte.utils.ClientKeyHelper;
import moze_intel.projecte.utils.PEKeybind;
import moze_intel.projecte.utils.text.PELang;
import net.fabricmc.api.EnvType;
import net.fabricmc.loader.api.FabricLoader;
import net.minecraft.ChatFormatting;
import net.minecraft.client.Minecraft;
import net.minecraft.client.player.LocalPlayer;
import net.minecraft.network.chat.Component;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.EquipmentSlot;
import net.minecraft.world.entity.EquipmentSlotGroup;
import net.minecraft.world.entity.ai.attributes.AttributeModifier;
import net.minecraft.world.entity.ai.attributes.AttributeModifier.Operation;
import net.minecraft.world.entity.ai.attributes.Attributes;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.TooltipFlag;
import net.minecraft.world.item.component.TooltipDisplay;
import net.minecraft.world.item.equipment.ArmorType;
import net.minecraft.world.phys.Vec3;
import org.jetbrains.annotations.NotNull;
import org.jetbrains.annotations.Nullable;

public class GemFeet extends GemArmorBase implements IHasConditionalAttributes {

	private static final Vec3 VERTICAL_MOVEMENT = new Vec3(0, 0.1, 0);
	private static final boolean STEP_ASSIST_DEFAULT = false;

	public GemFeet(Properties props) {
		super(ArmorType.BOOTS, props.component(PEDataComponentTypes.STEP_ASSIST.get(), STEP_ASSIST_DEFAULT));
		if (FabricLoader.getInstance().getEnvironmentType() == EnvType.CLIENT) {
			ClientHelper.register();
		}
	}

	@Override
	public void adjustAttributes(ItemStack stack, AttributeCollector collector) {
		collector.accept(Attributes.MOVEMENT_SPEED, new AttributeModifier(PECore.rl("armor"), 1.0, Operation.ADD_MULTIPLIED_TOTAL), EquipmentSlotGroup.FEET);
		if (isStepAssist(stack)) {
			collector.accept(Attributes.STEP_HEIGHT, new AttributeModifier(PECore.rl("gem_step_assist"), 0.4, Operation.ADD_VALUE), EquipmentSlotGroup.FEET);
		}
	}

	@Override
	public void appendHoverText(@NotNull ItemStack stack, @NotNull Item.TooltipContext context, @NotNull TooltipDisplay display, @NotNull Consumer<Component> tooltip, @NotNull TooltipFlag flags) {
		super.appendHoverText(stack, context, display, tooltip, flags);
		tooltip.accept(PELang.GEM_LORE_FEET.translate());
		tooltip.accept(PELang.STEP_ASSIST_PROMPT.translate(ClientKeyHelper.getKeyName(PEKeybind.BOOTS_TOGGLE)));
		tooltip.accept(getComponent(isStepAssist(stack)));
	}

	public static void toggleStepAssist(ItemStack boots, Player player) {
		boolean oldValue = isStepAssist(boots);
		boots.set(PEDataComponentTypes.STEP_ASSIST.get(), !oldValue);
		player.sendSystemMessage(getComponent(!oldValue));
	}

	private static boolean isStepAssist(ItemStack stack) {
		return stack.getOrDefault(PEDataComponentTypes.STEP_ASSIST.get(), STEP_ASSIST_DEFAULT);
	}

	private static Component getComponent(boolean stepAssist) {
		if (stepAssist) {
			return PELang.STEP_ASSIST.translate(ChatFormatting.GREEN, PELang.GEM_ENABLED);
		}
		return PELang.STEP_ASSIST.translate(ChatFormatting.RED, PELang.GEM_DISABLED);
	}

	@Override
	public void inventoryTick(@NotNull ItemStack stack, @NotNull ServerLevel level, @NotNull Entity entity, @Nullable EquipmentSlot slot) {
		super.inventoryTick(stack, level, entity, slot);
		if (isArmorSlot(slot) && entity instanceof Player player) {
			player.resetFallDistance();
		}
	}

	private void tickClient(Player player) {
		boolean flying = player.getAbilities().flying;
		if (!flying && ClientHelper.isJumpPressed(player)) {
			player.addDeltaMovement(VERTICAL_MOVEMENT);
		}

		if (!player.onGround()) {
			if (player.getDeltaMovement().y() <= 0) {
				player.setDeltaMovement(player.getDeltaMovement().multiply(1, 0.9, 1));
			}

			if (!flying) {
				if (player.zza < 0) {
					player.setDeltaMovement(player.getDeltaMovement().multiply(0.9, 1, 0.9));
				} else if (player.zza > 0 && player.getDeltaMovement().lengthSqr() < 3) {
					player.setDeltaMovement(player.getDeltaMovement().multiply(1.1, 1, 1.1));
				}
			}
		}
	}

	/**
	 * Client only holder for logic that must not be class loaded on a dedicated server.
	 */
	private static class ClientHelper {

		private static boolean registered;

		private static void register() {
			if (!registered) {
				registered = true;
				net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientTickEvents.START_CLIENT_TICK.register(ClientHelper::onStartTick);
			}
		}

		private static void onStartTick(Minecraft client) {
			LocalPlayer player = client.player;
			if (player != null && player.level().isClientSide() && player.getItemBySlot(EquipmentSlot.FEET).getItem() instanceof GemFeet feet) {
				feet.tickClient(player);
			}
		}

		private static boolean isJumpPressed(Player player) {
			return player instanceof LocalPlayer localPlayer && localPlayer.input.keyPresses.jump();
		}
	}
}
