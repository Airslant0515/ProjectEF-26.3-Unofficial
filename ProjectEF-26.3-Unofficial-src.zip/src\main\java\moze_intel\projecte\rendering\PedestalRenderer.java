package moze_intel.projecte.rendering;

import com.mojang.blaze3d.vertex.PoseStack;
import com.mojang.math.Axis;
import moze_intel.projecte.gameObjs.block_entities.DMPedestalBlockEntity;
import net.minecraft.client.renderer.SubmitNodeCollector;
import net.minecraft.client.renderer.blockentity.BlockEntityRenderer;
import net.minecraft.client.renderer.blockentity.BlockEntityRendererProvider;
import net.minecraft.client.renderer.blockentity.state.BlockEntityRenderState;
import net.minecraft.client.renderer.feature.ModelFeatureRenderer.CrumblingOverlay;
import net.minecraft.client.renderer.item.ItemModelResolver;
import net.minecraft.client.renderer.item.ItemStackRenderState;
import net.minecraft.client.renderer.state.level.CameraRenderState;
import net.minecraft.client.renderer.texture.OverlayTexture;
import net.minecraft.world.item.ItemDisplayContext;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.phys.Vec3;
import org.jetbrains.annotations.NotNull;
import org.jetbrains.annotations.Nullable;

public class PedestalRenderer implements BlockEntityRenderer<DMPedestalBlockEntity, PedestalRenderer.PedestalRenderState> {

	private final ItemModelResolver itemModelResolver;

	public PedestalRenderer(BlockEntityRendererProvider.Context context) {
		this.itemModelResolver = context.itemModelResolver();
	}

	@NotNull
	@Override
	public PedestalRenderState createRenderState() {
		return new PedestalRenderState();
	}

	@Override
	public void extractRenderState(@NotNull DMPedestalBlockEntity pedestal, @NotNull PedestalRenderState state, float partialTick,
			@NotNull Vec3 cameraPosition, @Nullable CrumblingOverlay breakProgress) {
		BlockEntityRenderer.super.extractRenderState(pedestal, state, partialTick, cameraPosition, breakProgress);
		state.item.clear();
		if (pedestal.isRemoved() || pedestal.getLevel() == null) {
			return;
		}
		ItemStack stack = pedestal.getInventory().getStackInSlot(0);
		if (stack.isEmpty()) {
			return;
		}
		state.time = pedestal.getLevel().getGameTime();
		this.itemModelResolver.updateForTopItem(state.item, stack, ItemDisplayContext.FIXED, pedestal.getLevel(), null, (int) pedestal.getBlockPos().asLong());
	}

	@Override
	public void submit(@NotNull PedestalRenderState state, @NotNull PoseStack poseStack, @NotNull SubmitNodeCollector collector, @NotNull CameraRenderState camera) {
		if (state.item.isEmpty()) {
			return;
		}
		poseStack.pushPose();
		poseStack.translate(0.5, 1.0, 0.5);
		float angle = (state.time % 80) / 80.0F * 360.0F;
		poseStack.rotate(Axis.YP.rotationDegrees(angle));
		poseStack.scale(0.6F, 0.6F, 0.6F);
		state.item.submit(poseStack, collector, state.lightCoords, OverlayTexture.NO_OVERLAY, 0);
		poseStack.popPose();
	}

	public static class PedestalRenderState extends BlockEntityRenderState {

		private final ItemStackRenderState item = new ItemStackRenderState();
		private long time;
	}
}