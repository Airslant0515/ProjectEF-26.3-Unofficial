package moze_intel.projecte.emc.components.processor;

import java.util.ArrayList;
import java.util.Collection;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.function.ToLongFunction;
import moze_intel.projecte.PECore;
import moze_intel.projecte.api.ItemInfo;
import moze_intel.projecte.api.components.DataComponentProcessor;
import moze_intel.projecte.api.components.IComponentProcessorHelper;
import moze_intel.projecte.api.proxy.IEMCProxy;
import moze_intel.projecte.config.PEConfigTranslations;
import net.minecraft.core.Holder;
import net.minecraft.core.component.DataComponentType;
import net.minecraft.core.component.DataComponents;
import net.minecraft.core.registries.BuiltInRegistries;
import net.minecraft.resources.Identifier;
import net.minecraft.resources.ResourceKey;
import net.minecraft.server.MinecraftServer;
import net.minecraft.tags.ItemTags;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.crafting.Ingredient;
import net.minecraft.world.item.crafting.RecipeHolder;
import net.minecraft.world.item.crafting.SmithingTrimRecipe;
import net.minecraft.world.item.crafting.display.RecipeDisplay;
import net.minecraft.world.item.crafting.display.SlotDisplay.SmithingTrimDemoSlotDisplay;
import net.minecraft.world.item.equipment.trim.ArmorTrim;
import net.minecraft.world.item.equipment.trim.TrimMaterial;
import net.minecraft.world.item.equipment.trim.TrimPattern;
import org.jetbrains.annotations.NotNull;
import org.jetbrains.annotations.Nullable;
import org.jetbrains.annotations.Range;

@DataComponentProcessor
public class ArmorTrimProcessor extends PersistentComponentProcessor<ArmorTrim> {

	@DataComponentProcessor.Instance
	public static final ArmorTrimProcessor INSTANCE = new ArmorTrimProcessor();

	@Nullable
	private Map<ResourceKey<TrimMaterial>, List<Item>> materials;
	private Map<ResourceKey<TrimPattern>, Ingredient> templates = Map.of();

	@Override
	public String getName() {
		return PEConfigTranslations.DCP_ARMOR_TRIM.title();
	}

	@Override
	public String getTranslationKey() {
		return PEConfigTranslations.DCP_ARMOR_TRIM.getTranslationKey();
	}

	@Override
	public String getDescription() {
		return PEConfigTranslations.DCP_ARMOR_TRIM.tooltip();
	}

	@Override
	@Range(from = 0, to = Long.MAX_VALUE)
	public long recalculateEMC(@NotNull ItemInfo info, @Range(from = 1, to = Long.MAX_VALUE) long currentEMC, @NotNull ArmorTrim trim) throws ArithmeticException {
		long materialEmc = trim.material().unwrapKey().map(this::getMaterialEmc).orElse(0L);
		if (materialEmc == 0) {
			//The material for the trim doesn't have an EMC value, so there is no valid EMC value for the applied trim as a whole
			return 0;
		}
		Ingredient template = getTemplate(trim.pattern());
		long templateEmc = template == null ? 0 : IComponentProcessorHelper.INSTANCE.getMinEmcFor(IEMCProxy.INSTANCE, template);
		if (templateEmc == 0) {
			//The template for the trim doesn't have an EMC value, and given the template is consumed: there is no valid EMC value for the applied trim as a whole
			return 0;
		}
		return Math.addExact(
				Math.addExact(currentEMC, materialEmc),
				templateEmc
		);
	}

	@Range(from = 0, to = Long.MAX_VALUE)
	private long getMaterialEmc(ResourceKey<TrimMaterial> material) {
		if (materials == null) {
			//Note: Trim materials don't have a direct reference to the item that provides them anymore, so we have to build the lookup ourselves
			Map<ResourceKey<TrimMaterial>, List<Item>> foundMaterials = new HashMap<>();
			for (Item item : BuiltInRegistries.ITEM) {
				Holder<TrimMaterial> provided = item.components().get(DataComponents.PROVIDES_TRIM_MATERIAL);
				if (provided != null) {
					provided.unwrapKey().ifPresent(key -> foundMaterials.computeIfAbsent(key, k -> new ArrayList<>()).add(item));
				}
			}
			materials = foundMaterials;
		}
		long minEmc = 0;
		for (Item item : materials.getOrDefault(material, List.of())) {
			long emc = IEMCProxy.INSTANCE.getValue(item);
			if (emc != 0 && (minEmc == 0 || emc < minEmc)) {
				minEmc = emc;
			}
		}
		return minEmc;
	}

	@Nullable
	private Ingredient getTemplate(Holder<TrimPattern> pattern) {
		ResourceKey<TrimPattern> key = pattern.unwrapKey().orElse(null);
		if (key == null) {
			return null;
		}
		Ingredient template = templates.get(key);
		if (template != null) {
			return template;
		}
		//Note: While on a server we use the template ingredient defined by the smithing trim recipe, the client doesn't always have access to
		// the recipe manager, so we fall back to the naming convention that is used for the vanilla trim patterns.
		Identifier templateId = Identifier.fromNamespaceAndPath(key.identifier().getNamespace(), key.identifier().getPath() + "_armor_trim_smithing_template");
		return BuiltInRegistries.ITEM.get(templateId).map(holder -> Ingredient.of(holder.value())).orElse(null);
	}

	@Override
	public void updateCachedValues(@Nullable ToLongFunction<ItemInfo> emcLookup) {
		materials = null;
		MinecraftServer server = PECore.getServer();
		if (server == null) {
			templates = Map.of();
		} else {
			updateTemplates(server.getRecipeManager().getRecipes());
		}
	}

	private void updateTemplates(Collection<? extends RecipeHolder<?>> recipes) {
		Map<ResourceKey<TrimPattern>, Ingredient> newTemplates = new HashMap<>();
		for (RecipeHolder<?> holder : recipes) {
			if (holder.value() instanceof SmithingTrimRecipe recipe) {
				Ingredient template = recipe.templateIngredient().orElse(null);
				if (template == null) {
					continue;
				}
				for (RecipeDisplay display : recipe.display()) {
					if (display.result() instanceof SmithingTrimDemoSlotDisplay trimDisplay) {
						trimDisplay.pattern().unwrapKey().ifPresent(pattern -> newTemplates.putIfAbsent(pattern, template));
					}
				}
			}
		}
		templates = newTemplates;
	}

	@Override
	protected boolean validItem(@NotNull ItemInfo info) {
		return info.getItem().is(ItemTags.TRIMMABLE_ARMOR);
	}

	@Override
	protected boolean shouldPersist(@NotNull ItemInfo info, @NotNull ArmorTrim component) {
		return true;
	}

	@Override
	protected DataComponentType<ArmorTrim> getComponentType(@NotNull ItemInfo info) {
		return DataComponents.TRIM;
	}
}
